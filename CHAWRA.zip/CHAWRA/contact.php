        <!-- Main Container -->
 <?php
									$one="Select * From tblcontactmidd LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
        <div class="container-fluid-kamn container">
		<div class="row container-kamn wow zoomIn">
			<img src="admin/img1/contact/<?php echo $three['contactmidd_img']; ?>" class="blog-post"  alt="Feature-img" align="right" height="300px" width="100%"> 
		</div>
		</br>
		
		
		<div class="panel panel-default">
				<div class="panel-heading" style="background:#99AABF;font-size:21px;color:#2D476F"><?php echo $three['contactmidd_title']; ?></div>
					<div class="panel-body" style="background-color:#F1F1F1">		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
            <div class="row wow zoomIn">
               
                <div class="col-lg-4 col-lg-offset-1">
                    <?php echo $three['contactmidd_cont']; ?>
					
                </div>
                <div class="col-lg-5">
                    <div class="feedback-form">
          
                        <div id="contact-response"></div>
						<p><b>Pimple Sudagar:-</b></br>
						<div class="col-xs-12 well">
							<div class="overlay" onclick="style.pointerEvents='none'" style="pointer-events: none;"></div>
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3781.4527521375135!2d73.79227999999999!3d18.5986949!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2b91e7b8da2e1%3A0x1fe2119fb1177afb!2sCS+Chirag+Chawra!5e0!3m2!1sen!2sin!4v1441016026064" width="100%" height="300px" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
        <!-- end map --> 
                       
						
						
						
                    </div> 
                </div>
			</div>
			<div class="row wow ZoomIn">
			<div class="col-lg-4 col-lg-offset-1">
			<h4>Contact Form:</h4>
             <div class="feedback-form">
          
                  <div id="contact-response"></div>
            
                       
                            <form  class="form-horizontal comment-form" role="form" action="save/savedata.php"  id="registerform"  method="post"    enctype="multipart/form-data">
						 <input type="hidden" name="process"  value="AddNewcontacts" readonly="readonly" required="required" />
                                <div class="form-group">
                                    <label class="control-label" for="fullname">NAME *</label>
                                    <input type="text" class="form-control" name="apply_name"  placeholder="Enter Your Name">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="email">E-MAIL *</label>
                                    <input type="text" class="form-control" name="apply_email" placeholder="Enter Your E-Mail">
                                </div>
								<div class="form-group">
                                    <label class="control-label" for="mob">Mobile no *</label>
                                    <input type="text" class="form-control" name="apply_mob" placeholder="Enter Your Mobile no">
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="message">MESSAGE *</label>
                                    <textarea class="form-control" name="apply_message"  rows="3"></textarea>
                                </div>           
                                <button type="submit" class="btn btn-primary">Submit</button>
                            
                        </form>
            </div>
							
					
			</div>
			
			
			
			 <div class="col-lg-5">
                    <div class="feedback-form">
						<p><b>Pimpri Office:-</b></br>
							<div class="col-xs-12 well">
								<div class="overlay" onclick="style.pointerEvents='none'" style="pointer-events: none;"></div>
								<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15122.802678849714!2d73.8010039!3d18.6325285!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x129a787a1a9745ac!2sChirag+Chawra+%26+Co!5e0!3m2!1sen!2sin!4v1441179438491" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe> 
							</div>		
			
			</div>
		
          </div>			
			</div>
			
			
			</div>
			</div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
        </div>    
          <?PHP   } ?>
    <!--End Main Container -->
<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/.test(value);
}, "Letters and spaces only"); 
$k('#registerform').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",

rules:{
	
					apply_name:{
						 required: true,
						 lettersonly:true
					},
					apply_message:"required",
					apply_email: {
                        required: true,
                        email: true
						
						
                    },     
					apply_mob: {
                        required: true,
                        maxlength:10,
						minlength:10,
						number:true
                    }
                   
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
//alert('aaaa')


$('#Success_Popupp').modal('show');
}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 

<?php include("modal.php")?>