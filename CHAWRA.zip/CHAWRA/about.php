    <!-- Main Container -->

    

    <div id="banners"></div>
	 <?php
									$one="Select * From tblaboutmidd LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
    <div class="container">  
	<div class="row container-kamn wow zoomIn">
        <img src="admin/img1/aboutus/<?php echo $three['aboutmidd_img']; ?>" class="blog-post"  alt="Feature-img" align="right" height="300px" width="100%"> 
    </div>	
	    <div class="row">
		
            <div class="col-md-12">
                <h3 class="lead"id="anchor1"></h3><hr>
				
				<div class="panel panel-default">
					  <div class="panel-heading" style="background:#99AABF;font-size:21px;color:#2D476F"><?php echo $three['aboutmidd_title']; ?></div>
						<div class="panel-body" style="color:#5A579A;">
						
						
						
						<div class="col-md-12 animated wow fadeInLeft" style="background-color:#F1F1F1">
							<p>
								<?php echo $three['aboutmidd_content']; ?>
							</p>
						</div>
						
						</div>
				</div>
			</div>  
		</div>
			<?PHP   } ?>
			
		<div class="row">
		    <div class="panel panel-default">
			<?php
									$one="Select * From tblaboutlast LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
				<div class="panel-heading" style="background:#99AABF;font-size:21px;color:#2D476F"><?php echo $three['aboutlast_pantitle']; ?></div>
				<?php } ?>
					<div class="panel-body" style="background-color:#F1F1F1">
					
						<div class="col-md-6">
						<?php
									$one="Select * From tblaboutlast LIMIT 2";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
							<div class="blockquote-info animated wow fadeInDownBig clearfix " >
								<div class="box-content thumbnail text-center">
											<a href="#" class="item-image">
												<img class="img-responsive img-aa" style="height:160px;" src="admin/img1/team/<?php echo $three['aboutlast_img']; ?>" alt="">
												<h3>
													<span><?php echo $three['aboutlast_empname']; ?></span> <br>
													<span><?php echo $three['aboutlast_emppos']; ?></span>
												</h3>
											</a>
											<div class="caption text-left">
												<p><?php echo $three['aboutlast_propcont']; ?></p>
												
											</div>
								</div>
							</div>
						<?PHP   } ?>	
                
						</div>
						<div class="col-md-6">
						<?php
									$one="Select * From tblaboutlast  ORDER BY aboutlast_id DESC LIMIT 2";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
							<div class="blockquote-success animated wow fadeInDownBig clearfix">
								<div class="box-content thumbnail text-center">
									<a href="#" class="item-image">
										<img class="img-responsive img-aa" style="height:160px;" src="admin/img1/team/<?php echo $three['aboutlast_img']; ?>" alt="">
										<h3>
											<span><?php echo $three['aboutlast_empname']; ?></span> <br>
											<span><?php echo $three['aboutlast_emppos']; ?></span>
										</h3>
									</a>
									<div class="caption text-left">
										<p><?php echo $three['aboutlast_propcont']; ?></p>
										
									</div>
								</div>
							</div>
							<?PHP   } ?>	
						
						</div>
					</div>
			</div>
		</div>       
	</div>
 

    <!--End Main Container -->