<?PHP 
session_start();
include("connect/connect.php"); 
?>
<?php error_reporting(E_ERROR | E_WARNING | E_PARSE); ?>




<?php 
	if($_REQUEST['process']=='TryMeNowww' && $_REQUEST['processNoee']=='TryFfloggINN' && $_REQUEST['user_name']!='' && $_REQUEST['user_pass']!='')
	{
		
		$user_name=mysql_real_escape_string($_REQUEST['user_name']);
		$user_pass=mysql_real_escape_string($_REQUEST['user_pass']);
		
$sql="select * from tbluser where user_name='$user_name' AND user_pass='$user_pass' AND user_access='1'";
$result=mysql_query($sql);
if($row=mysql_fetch_array($result))
		{
			$_SESSION['admin_user_id']=$row['user_id'];
			$_SESSION['admin_user_full_name']=$row['user_full_name'];
			$_SESSION['admin_user_type']=$row['user_type'];
			$_SESSION['admin_user_s_type']=$row['user_s_type'];
			$_SESSION['admin_user_access']=$row['user_access'];
			
			$_SESSION['admin_user_name']=$row['user_name'];
			$_SESSION['admin_user_email']=$row['user_email'];
	?>
<script type="text/javascript">
window.location="index.php";
</script>
		<?PHP
        }
else 
		{
		session_destroy();	
		echo '<div style="color:red; font-size:19px;" align="center"><strong>Username Or Password Wrong Try Again..</strong></div>';
		}

}
?>


<?php

if($_SESSION['admin_user_id']!='')
{
?>


<?Php include("header.php"); ?>

<?PHP
	if($_REQUEST['page']!='')
    {
        include($_REQUEST['page'].".php");	
    }
    else
	{
        include_once("body.php");
		
    }
?>

<?Php include("footer.php"); ?>


<?php
}
else
{
include('login.php');	
}
?>
