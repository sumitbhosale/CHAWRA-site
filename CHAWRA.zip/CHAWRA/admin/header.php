<!DOCTYPE html>
<html>


<head>
<title>Thin Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="css/bootstrap.css" rel="stylesheet" media="screen">
<link href="css/thin-admin.css" rel="stylesheet" media="screen">
<link href="css/font-awesome.css" rel="stylesheet" media="screen">
<link href="style/style.css" rel="stylesheet">
<link href="style/dashboard.css" rel="stylesheet">
<link href="css/demo_page.css" rel="stylesheet">
<link href="css/demo_table.css" rel="stylesheet">
<link rel='stylesheet' type='text/css' href='assets/jquery-fileupload/css/jquery.fileupload-ui.css' /> 
<link rel="stylesheet" href="style/screen.css" media="screen"/>

<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script> 





<link rel="stylesheet" type="text/css" href="css/prettify.css"></link>
<link rel="stylesheet" type="text/css" href="css/bootstrap-wysihtml5.css"></link>



</head>



<body>
<div class="container">
  <div class="top-navbar header b-b"> <a data-original-title="Toggle navigation" class="toggle-side-nav pull-left" href="#"><i class="icon-reorder"></i> </a>
    <div class="brand pull-left"> <a href="index.php"><img src="images/logo.png" width="147" height="33"></a></div>
    <ul class="nav navbar-nav navbar-right  hidden-xs">

 
     
      <li class="dropdown user  hidden-xs"> <a data-toggle="dropdown" class="dropdown-toggle" href="#"> <i class="icon-male"></i> <span class="username">John Doe</span> <i class="icon-caret-down small"></i> </a>
        <ul class="dropdown-menu">
         
      
          <li><a href="signout.php"><i class="icon-key"></i>Log Out</a></li>
        </ul>
      </li>
    </ul>
   
  </div>
</div>
<div class="wrapper">
  <div class="left-nav">
    <div id="side-nav">
      <ul id="nav">
        <li class="current"> <a href="index.php"> <i class="icon-dashboard"></i> Dashboard </a> </li>
        <li> <a href="#"> <i class="icon-desktop"></i>Home Page<i class="arrow icon-angle-left"></i></a>
          <ul class="sub-menu">
            <li> <a href="index.php?page=addslider"> <i class="icon-angle-right"></i> Slider images </a> </li>
            <li> <a href="index.php?page=addmiddle"> <i class="icon-angle-right"></i> Middle Part </a> </li>
             
          </ul>
        </li>
		<li> <a href="#"> <i class="icon-desktop"></i>About Page<i class="arrow icon-angle-left"></i></a>
          <ul class="sub-menu">
            <li><a href="index.php?page=addaboutmiddle"> <i class="icon-angle-right"></i>Middle Part</a> </li>
			<li><a href="index.php?page=addaboutlast"> <i class="icon-angle-right"></i>Last Part</a> </li>
         
          
          </ul>
        </li>
		<li> <a href="#"> <i class="icon-desktop"></i>Services Page<i class="arrow icon-angle-left"></i></a>
          <ul class="sub-menu">
		  <li><a href="index.php?page=addservicestop"> <i class="icon-angle-right"></i>Top Part</a> </li>
           <li><a href="index.php?page=addservicesmiddle"> <i class="icon-angle-right"></i>Middle Part</a> </li>
             <li><a href="index.php?page=addservicesside"> <i class="icon-angle-right"></i>Side Part</a> </li>
           
          </ul>
        </li>
		<li> <a href="#"> <i class="icon-desktop"></i>Blog Page<i class="arrow icon-angle-left"></i></a>
          <ul class="sub-menu">
            <li> <a href="index.php?page=addblogtop"> <i class="icon-angle-right"></i>Top Part</a> </li>
            <li><a href="index.php?page=addblogmiddle"> <i class="icon-angle-right"></i>Middle Part</a> </li>
         
          </ul>
        </li>
		<li> <a href="#"> <i class="icon-desktop"></i>Important Link Page<i class="arrow icon-angle-left"></i></a>
          <ul class="sub-menu">
         <li> <a href="index.php?page=addimportanttop"> <i class="icon-angle-right"></i>Top Part</a> </li>
             <li> <a href="index.php?page=addimportantmidd"> <i class="icon-angle-right"></i>Middle Part</a> </li>
           
          </ul>
        </li>
		<li> <a href="#"> <i class="icon-desktop"></i>Faqs Page<i class="arrow icon-angle-left"></i></a>
          <ul class="sub-menu">
            <li> <a href="index.php?page=addfaqshole"> <i class="icon-angle-right"></i> Faqs Hole Part </a> </li>
           
           
          </ul>
        </li>
		<li> <a href="#"> <i class="icon-desktop"></i>Contact Page<i class="arrow icon-angle-left"></i></a>
          <ul class="sub-menu">
            <li> <a href="index.php?page=addcontactmiddle"> <i class="icon-angle-right"></i>Contact Midd Page</a> </li>
           
           
          </ul>
        </li>
       
    
      </ul>
    </div>
  </div>
  <?php include("modalll.php")?>