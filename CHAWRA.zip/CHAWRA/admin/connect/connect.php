<?php
ini_set('session.bug_compat_warn', 0);
ini_set('session.bug_compat_42', 0);
error_reporting(E_ERROR | E_WARNING | E_PARSE);

$hostname = "localhost"; //Mysql Hostname
$db_username = "root"; //Database Username
$db_password = ""; //Database Password
$db_name = "cschir2_chawra_database"; //Database Name




mysql_connect($hostname, $db_username, $db_password);
mysql_select_db($db_name);


date_default_timezone_set('Asia/Kolkata');
?>