<?PHP include('connect/connect.php'); ?>
<?php $yes=0; ?>
<?php


if($_REQUEST['processLogic']=='AddANewwSliddrrss')
{		
		
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/slider/".$imagename;
				
				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
					
					$submission_date= date("Y-m-d");
					
					
					$one="insert into tblslider (slider_img) values ('$imagename')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addslider'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addslider'>";
					}
     

			}


		}

		
	
	
}
?>


<?php


if($_REQUEST['processLogic']=='EditANewwSliddrrss')
{		
		$sliderid=$_REQUEST['sliderid'];
		
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/slider/".$imagename;
				
     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

				 $on="select slider_img from  tblslider WHERE slider_id='$sliderid'";
				 $tw=mysql_query($on);
				 $nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='../img1/slider/'.$row['slider_img'];
						$yes=unlink($file);
					}
					
					
					$one="Update tblslider SET slider_img='$imagename' WHERE slider_id='$sliderid'";
					
				
		
					$two=mysql_query($one);
				
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addslider'>";
					}
					else
					{
					
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addslider'>";
					}
     

			}


		}

		
	
	
}
?>


<?php


if($_REQUEST['processLogic']=='DeleteANewwSliddrrss')
{		
		
					$sliderid=$_REQUEST['sliderid'];
					
					$on="select slider_img from  tblslider WHERE slider_id='$sliderid'";
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='../img1/slider/'.$row['slider_img'];
						$yes=unlink($file);
					}
					
					
					
					
					$one="Delete FROM tblslider WHERE slider_id='$sliderid'";
				    $two=mysql_query($one);
		
					if($two && $yes)
					{	
						echo "Content Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=../index.php?page=addslider'>";	
					}
					else
					{
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=../index.php?page=addslider'>";	
					
					}
     

		


		

		
	
	
}
?>

<?php


if($_REQUEST['processLogic']=='AddANewwhomemiddpara')
{		
		$homemidd_title=$_REQUEST['homemidd_title'];
		$homemidd_content=$_REQUEST['homemidd_content'];
		


 

					$one="insert into tblhomemidd (homemidd_content,homemidd_title) values ('$homemidd_content','$homemidd_title')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
					
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";
					}
					else
					{
				
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";
					}
	
}
?>
<?php


if($_REQUEST['processLogic']=='Edithomemiddpara')
{		
		$homemidd_title=$_REQUEST['homemidd_title'];
		$homemidd_content=$_REQUEST['homemidd_content'];
		$homemidd_id=$_REQUEST['homemidd_id'];
		

			$one="Update tblhomemidd SET homemidd_title='$homemidd_title',homemidd_content='$homemidd_content' WHERE homemidd_id='$homemidd_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";
					}
					else
					{

						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";
					}
     


		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Deletehomemiddpara')
{		
			
					$homemidd_id=$_REQUEST['homemidd_id'];
					
					
					$on="select tblhomemiddimages.homemiddimages_img FROM tblhomemidd LEFT JOIN tblhomemiddimages ON tblhomemiddimages.homemiddimages_homemidd_id=tblhomemidd.homemidd_id WHERE homemidd_id='$homemidd_id'";
					
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						while($row=mysql_fetch_assoc($tw))
						{
							if($row['homemiddimages_img']!=NULL)
							{
							$file='img1/visionmissiongoal/'.$row['homemiddimages_img'];
							$yes=unlink($file);
							}else if($row['homemiddimages_img']==NULL)
							{
							$yes=1;
							}
						}
					}
				
					
					
					
					$one="DELETE tblhomemidd,tblhomemiddimages FROM tblhomemidd LEFT JOIN tblhomemiddimages ON tblhomemiddimages.homemiddimages_homemidd_id=tblhomemidd.homemidd_id WHERE homemidd_id='$homemidd_id'";
		
		
				    $two=mysql_query($one);
				
					if($two && $yes)
					{	
					
						echo "Record Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addmiddle'>";	
					}
					else
					{
						

						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addmiddle'>";	
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwhomemiddparaimg')
{		$homemiddimages_content=$_REQUEST['homemiddimages_content'];
		$homemiddimages_title=$_REQUEST['homemiddimages_title'];
			$homemiddimages_homemidd_id=$_REQUEST['homemiddimages_homemidd_id'];
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/visionmissiongoal/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

			

			
					$one="insert into tblhomemiddimages (homemiddimages_img,homemiddimages_title,homemiddimages_content,homemiddimages_homemidd_id) values ('$imagename','$homemiddimages_title','$homemiddimages_content','$homemiddimages_homemidd_id')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";	
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";	
					
					}
     

			}


		}

		
	
	
}
?>


<?php


if($_REQUEST['processLogic']=='EditANewwhomemiddparaimg')
{		

		$homemiddimages_title=$_REQUEST['homemiddimages_title'];
		$homemiddimages_content=$_REQUEST['homemiddimages_content'];
		$homemiddimages_id=$_REQUEST['homemiddimages_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/visionmissiongoal/".$imagename;

				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
					
					 $on="select homemiddimages_img from  tblhomemiddimages WHERE homemiddimages_id='$homemiddimages_id'";
				
						$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
						{
							$row=mysql_fetch_assoc($tw);
							
							
							$file="../img1/visionmissiongoal/".$row['homemiddimages_img'];
							$yes=unlink($file);
						}
				
					
					
					
						
					
					
			
		
					$one="Update tblhomemiddimages SET homemiddimages_img='$imagename',homemiddimages_content='$homemiddimages_content',homemiddimages_title='$homemiddimages_title' WHERE homemiddimages_id='$homemiddimages_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";	
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";	
					}
     

			}


		}else
		{
			
			
			$one="Update tblhomemiddimages SET homemiddimages_content='$homemiddimages_content',homemiddimages_title='$homemiddimages_title' WHERE homemiddimages_id='$homemiddimages_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";	
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addmiddle'>";	
					}
     
			
		}

		
	
	
}
?>

<?php


if($_REQUEST['processLogic']=='DeleteANewwhomemiddparaimg')
{		
		
					$homemiddimages_id=$_REQUEST['homemiddimages_id'];
					
		
					
				 $on="select homemiddimages_img from  tblhomemiddimages WHERE homemiddimages_id='$homemiddimages_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file="img1/visionmissiongoal/".$row['homemiddimages_img'];
						$yes=unlink($file);
					}
					
					$one="DELETE  FROM  tblhomemiddimages  WHERE homemiddimages_id='$homemiddimages_id'";
					$two=mysql_query($one);
				
	
					if($two && $yes)
					{	
					
						echo "Record Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addmiddle'>";
					}
					else
					{
						

						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addmiddle'>";
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwaboutmiddpart')
{	
	$aboutmidd_content=$_REQUEST['aboutmidd_content'];
	$aboutmidd_title=$_REQUEST['aboutmidd_title'];
	
	
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/aboutus/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

			

			
					$one="insert into tblaboutmidd (aboutmidd_img,aboutmidd_title,aboutmidd_content) values ('$imagename','$aboutmidd_title','$aboutmidd_content')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutmiddle'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutmiddle'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editaboutmiddpart')
{		

		$aboutmidd_title=$_REQUEST['aboutmidd_title'];
		$aboutmidd_content=$_REQUEST['aboutmidd_content'];
		$aboutmidd_id=$_REQUEST['aboutmidd_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/aboutus/".$imagename;
				
				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
					 $on="select aboutmidd_img from  tblaboutmidd WHERE aboutmidd_id='$aboutmidd_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/aboutus/'.$row['aboutmidd_img'];
						$yes=unlink($file);
					}
					
			
					$one="Update tblaboutmidd SET aboutmidd_img='$imagename',aboutmidd_content='$aboutmidd_content',aboutmidd_title='$aboutmidd_title' WHERE aboutmidd_id='$aboutmidd_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutmiddle'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutmiddle'>";
					}
     

			}


		}else
		{
			
			
			$one="Update tblaboutmidd SET aboutmidd_content='$aboutmidd_content',aboutmidd_title='$aboutmidd_title' WHERE aboutmidd_id='$aboutmidd_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutmiddle'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutmiddle'>";
					}
     
			
		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Deleteaboutmiddpart')
{		
		
					$aboutmidd_id=$_REQUEST['aboutmidd_id'];
					
					
					 $on="select aboutmidd_img from  tblaboutmidd WHERE aboutmidd_id='$aboutmidd_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='img1/aboutus/'.$row['aboutmidd_img'];
						$yes=unlink($file);
					}
					
					
					
					
					
					$one="DELETE  FROM  tblaboutmidd  WHERE aboutmidd_id='$aboutmidd_id'";
		
					
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
					
						echo "Record Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addaboutmiddle'>";
					}
					else
					{
						

						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addaboutmiddle'>";
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwaboutlastpart')
{	
	$aboutlast_pantitle=$_REQUEST['aboutlast_pantitle'];
	$aboutlast_empname=$_REQUEST['aboutlast_empname'];
	$aboutlast_emppos=$_REQUEST['aboutlast_emppos'];
	$aboutlast_propcont=$_REQUEST['aboutlast_propcont'];
	
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/team/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

			

			
					$one="insert into tblaboutlast (aboutlast_img,aboutlast_pantitle,aboutlast_empname,aboutlast_emppos,aboutlast_propcont) values ('$imagename','$aboutlast_pantitle','$aboutlast_empname','$aboutlast_emppos','$aboutlast_propcont')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutlast'>";
					}
					else
					{
						
						echo "Faill";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutlast'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editaboutlastpart')
{		

		$aboutlast_pantitle=$_REQUEST['aboutlast_pantitle'];
		$aboutlast_empname=$_REQUEST['aboutlast_empname'];
		$aboutlast_emppos=$_REQUEST['aboutlast_emppos'];
	    $aboutlast_propcont=$_REQUEST['aboutlast_propcont'];
		$aboutlast_id=$_REQUEST['aboutlast_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/team/".$imagename;

				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
				   $on="select aboutlast_img from  tblaboutlast WHERE aboutlast_id='$aboutlast_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='../img1/team/'.$row['aboutlast_img'];
						$yes=unlink($file);
					}
			
			

					$one="Update tblaboutlast SET aboutlast_img='$imagename',aboutlast_pantitle='$aboutlast_pantitle',aboutlast_empname='$aboutlast_empname',aboutlast_emppos='$aboutlast_emppos',aboutlast_propcont='$aboutlast_propcont' WHERE aboutlast_id='$aboutlast_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutlast'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutlast'>";
					}
     

			}


		}else
		{
			
			
			$one="Update tblaboutlast SET aboutlast_pantitle='$aboutlast_pantitle',aboutlast_empname='$aboutlast_empname',aboutlast_emppos='$aboutlast_emppos',aboutlast_propcont='$aboutlast_propcont' WHERE aboutlast_id='$aboutlast_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutlast'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addaboutlast'>";
					}
     
			
		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Deleteaboutlastpart')
{		
		
					$aboutlast_id=$_REQUEST['aboutlast_id'];
					
					$on="select aboutlast_img from  tblaboutlast WHERE aboutlast_id='$aboutlast_id'";
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='img1/team/'.$row['aboutlast_img'];
						$yes=unlink($file);
					}
					
					$one="DELETE  FROM  tblaboutlast  WHERE aboutlast_id='$aboutlast_id'";
		
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
					
						echo "Record Deleted Successfully";	
							echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addaboutlast'>";
					}
					else
					{
						

						echo "Faill";	
							echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addaboutlast'>";
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwservicemiddpart')
{	
	$servicemidd_pantitle=$_REQUEST['servicemidd_pantitle'];
	$servicemidd_servicetitle=$_REQUEST['servicemidd_servicetitle'];
	$servicemidd_servicecont=$_REQUEST['servicemidd_servicecont'];
	
	
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];
				
				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];
				

				$imgtype=$_FILES["apply_fileToUpload"]["type"];
				

				$ext= GetImageExtension($imgtype);
				

				$imagename=uniqid().$file_name;
				

				$target_path = "../img1/services/".$imagename;
				

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

			

			
					$one="insert into tblservicemidd (servicemidd_pantitle,servicemidd_servicetitle,servicemidd_servicecont,servicemidd_serviceimg) values ('$servicemidd_pantitle','$servicemidd_servicetitle','$servicemidd_servicecont','$imagename')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesmiddle'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesmiddle'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editservicesmiddpart')
{		

		$servicemidd_pantitle=$_REQUEST['servicemidd_pantitle'];
		$servicemidd_servicetitle=$_REQUEST['servicemidd_servicetitle'];
		$servicemidd_servicecont=$_REQUEST['servicemidd_servicecont'];
	  
		$servicemidd_id=$_REQUEST['servicemidd_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/services/".$imagename;

				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
				
			
					 $on="select servicemidd_serviceimg from  tblservicemidd WHERE servicemidd_id='$servicemidd_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/services/'.$row['servicemidd_serviceimg'];
						$yes=unlink($file);
					}
					
			
			
			
					$one="Update tblservicemidd SET servicemidd_pantitle='$servicemidd_pantitle',servicemidd_servicetitle='$servicemidd_servicetitle',servicemidd_servicecont='$servicemidd_servicecont',servicemidd_serviceimg='$imagename' WHERE servicemidd_id='$servicemidd_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesmiddle'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesmiddle'>";
					}
     

			}


		}else
		{
			
			
			$one="Update tblservicemidd SET servicemidd_pantitle='$servicemidd_pantitle',servicemidd_servicetitle='$servicemidd_servicetitle',servicemidd_servicecont='$servicemidd_servicecont' WHERE servicemidd_id='$servicemidd_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesmiddle'>";
					
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesmiddle'>";
					
					}
     
			
		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Deleteservicesmiddpart')
{		
		
					$servicemidd_id=$_REQUEST['servicemidd_id'];
								
					 $on="select servicemidd_serviceimg from  tblservicemidd WHERE servicemidd_id='$servicemidd_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='img1/services/'.$row['servicemidd_serviceimg'];
						$yes=unlink($file);
					}
					
					
					
					
					
					
					$one="DELETE  FROM  tblservicemidd  WHERE servicemidd_id='$servicemidd_id'";
		
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
					
						echo "Record Deleted Successfully";	
							echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addservicesmiddle'>";
					}
					else
					{
						

						echo "Faill";	
							echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addservicesmiddle'>";
					}
     

		


		

		
	
	
}
?>

<?php


if($_REQUEST['processLogic']=='AddANewwservicestoppart')
{	
	
	
	
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];
				
				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];
				

				$imgtype=$_FILES["apply_fileToUpload"]["type"];
				

				$ext= GetImageExtension($imgtype);
				

				$imagename=uniqid().$file_name;
				

				$target_path = "../img1/services/".$imagename;
				

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

			

			
					$one="insert into tblservicetop (servicetop_img) values ('$imagename')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicestop'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicestop'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editservicestoppart')
{		
		$servicetop_id=$_REQUEST['servicetop_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/services/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
					$on="select servicetop_img from  tblservicetop WHERE servicetop_id='$servicetop_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/services/'.$row['servicetop_img'];
						$yes=unlink($file);
					}
					
				
					
					$one="Update tblservicetop SET servicetop_img='$imagename' WHERE servicetop_id='$servicetop_id'";

				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicestop'>";
					}
					else
					{
					
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicestop'>";
					}
     

			}


		}

		
	
	
}
?>


<?php


if($_REQUEST['processLogic']=='Deleteservicestoppart')
{		
		
					$servicetop_id=$_REQUEST['servicetop_id'];
					
					$on="select servicetop_img from  tblservicetop WHERE servicetop_id='$servicetop_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='img1/services/'.$row['servicetop_img'];
						$yes=unlink($file);
					}
					
					
					
					
					$one="Delete FROM tblservicetop WHERE servicetop_id='$servicetop_id'";
				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						
						
						
						echo "Content Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addservicestop'>";
					}
					else
					{
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addservicestop'>";
					
					
					
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwservicesidepart')
{		
		$serviceside_link=$_REQUEST['serviceside_link'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/services/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

					

			
					$one="insert into tblserviceside (serviceside_img,serviceside_link) values ('$imagename','$serviceside_link')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesside'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesside'>";
					
					}
     

			}


		}

		
	
	
}
?>

<?php


if($_REQUEST['processLogic']=='Editservicessidepart')
{		
$serviceside_link=$_REQUEST['serviceside_link'];
		
		$serviceside_id=$_REQUEST['serviceside_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/services/".$imagename;

				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{		
				 $on="select serviceside_img from  tblserviceside WHERE serviceside_id='$serviceside_id'";
				
				$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/services/'.$row['serviceside_img'];
						$yes=unlink($file);
					}
					
					$one="Update tblserviceside SET serviceside_link='$serviceside_link',serviceside_img='$imagename' WHERE serviceside_id='$serviceside_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesside'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesside'>";
					}
     

			}


		}else
		{
			
			
			$one="Update tblserviceside SET serviceside_link='$serviceside_link' WHERE serviceside_id='$serviceside_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesside'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addservicesside'>";
					}
     
			
		}

		
	
	
}
?>


<?php


if($_REQUEST['processLogic']=='Deleteservicessidepart')
{		
		
					$serviceside_id=$_REQUEST['serviceside_id'];
					
					$on="select serviceside_img from  tblserviceside WHERE serviceside_id='$serviceside_id'";
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='img1/services/'.$row['serviceside_img'];
						$yes=unlink($file);
					}
					
					
					
					$one="Delete FROM tblserviceside WHERE serviceside_id='$serviceside_id'";
				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						
						
						
						echo "Content Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addservicesside'>";
						
					}
					else
					{
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addservicesside'>";
					
					
					
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwblogtoppart')
{		
		
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/blog/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

					$submission_date= date("Y-m-d");

			
					$one="insert into tblblogtop (blogtop_img) values ('$imagename')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogtop'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogtop'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editblogtoppart')
{		
		
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/blog/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

				
					$blogtop_id=$_REQUEST['blogtop_id'];
					
					
					$on="select blogtop_img from  tblblogtop WHERE blogtop_id='$blogtop_id'";
				$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='../img1/blog/'.$row['blogtop_img'];
						$yes=unlink($file);
					}
					
					
					
					$one="Update tblblogtop SET blogtop_img='$imagename' WHERE blogtop_id='$blogtop_id'";

				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogtop'>";
					}
					else
					{
					
						echo "Faill";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogtop'>";
					}
     

			}


		}

		
	
	
}
?>

<?php


if($_REQUEST['processLogic']=='Deleteblogtoppart')
{		
		
					$blogtop_id=$_REQUEST['blogtop_id'];
					
					$on="select blogtop_img from  tblblogtop WHERE blogtop_id='$blogtop_id'";
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='img1/blog/'.$row['blogtop_img'];
						$yes=unlink($file);
					}
					
					
					$one="Delete FROM tblblogtop WHERE blogtop_id='$blogtop_id'";
				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						
						
						
						echo "Content Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addblogtop'>";
					}
					else
					{
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addblogtop'>";
					
					
					
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwblogmiddpart')
{	
	$blogmidd_pantitle=$_REQUEST['blogmidd_pantitle'];
	$blogmidd_blogtitle=$_REQUEST['blogmidd_blogtitle'];
	$blogmidd_blogcont=$_REQUEST['blogmidd_blogcont'];
	
	
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];
				
				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];
				

				$imgtype=$_FILES["apply_fileToUpload"]["type"];
				

				$ext= GetImageExtension($imgtype);
				

				$imagename=uniqid().$file_name;
				

				$target_path = "../img1/blog/".$imagename;
				

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

			
					$submission_date= date("Y-m-d");
			
					$one="insert into tblblogmidd (blogmidd_pantitle,blogmidd_blogtitle,blogmidd_blogimg,blogmidd_blogcont,blogmidd_blogdate) values ('$blogmidd_pantitle','$blogmidd_blogtitle','$imagename','$blogmidd_blogcont','$submission_date')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogmiddle'>";
					}
					else
					{
						
						echo "Faill";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogmiddle'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editblogmiddpart')
{		

		$blogmidd_pantitle=$_REQUEST['blogmidd_pantitle'];
		$blogmidd_blogtitle=$_REQUEST['blogmidd_blogtitle'];
		$blogmidd_blogcont=$_REQUEST['blogmidd_blogcont'];
	  
		$blogmidd_id=$_REQUEST['blogmidd_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/blog/".$imagename;

				$submission_date= date("Y-m-d");

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
			
					$on="select blogmidd_blogimg from  tblblogmidd WHERE blogmidd_id='$blogmidd_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/blog/'.$row['blogmidd_blogimg'];
						$yes=unlink($file);
					}
			
			

					$one="Update tblblogmidd SET blogmidd_pantitle='$blogmidd_pantitle',blogmidd_blogtitle='$blogmidd_blogtitle',blogmidd_blogimg='$imagename',blogmidd_blogcont='$blogmidd_blogcont',blogmidd_blogdate='$submission_date' WHERE blogmidd_id='$blogmidd_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogmiddle'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogmiddle'>";
					}
     

			}


		}else
		{
			
			
			$one="Update tblblogmidd SET blogmidd_pantitle='$blogmidd_pantitle',blogmidd_blogtitle='$blogmidd_blogtitle',blogmidd_blogcont='$blogmidd_blogcont',blogmidd_blogdate='$submission_date' WHERE blogmidd_id='$blogmidd_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogmiddle'>";
					}
					else
					{
						

						
						echo "Faill";	
							echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addblogmiddle'>";
					}
     
			
		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Deleteblogmiddpart')
{		
		
					$blogmidd_id=$_REQUEST['blogmidd_id'];
					
					$on="select blogmidd_blogimg from  tblblogmidd WHERE blogmidd_id='$blogmidd_id'";
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='img1/blog/'.$row['blogmidd_blogimg'];
						$yes=unlink($file);
					}
					
					
					
					
					
					$one="DELETE  FROM  tblblogmidd  WHERE blogmidd_id='$blogmidd_id'";
		
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
					
						echo "Record Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addblogmiddle'>";
					}
					else
					{
						

						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addblogmiddle'>";
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwfaqsholepart')
{	
	$faqshole_title=$_REQUEST['faqshole_title'];
	$faqshole_cont=$_REQUEST['faqshole_cont'];
	
	
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/faqs/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

			

			
					$one="insert into tblfaqshole (faqshole_img,faqshole_title,faqshole_cont) values ('$imagename','$faqshole_title','$faqshole_cont')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addfaqshole'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addfaqshole'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editfaqsholepart')
{		

		$faqshole_title=$_REQUEST['faqshole_title'];
		$faqshole_cont=$_REQUEST['faqshole_cont'];
		
	  
		$faqshole_id=$_REQUEST['faqshole_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/faqs/".$imagename;

				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

					$on="select faqshole_img from  tblfaqshole WHERE faqshole_id='$faqshole_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/faqs/'.$row['faqshole_img'];
						$yes=unlink($file);
					}
					
			
			
			
					$one="Update tblfaqshole SET faqshole_title='$faqshole_title',faqshole_cont='$faqshole_cont',faqshole_img='$imagename' WHERE faqshole_id='$faqshole_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addfaqshole'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addfaqshole'>";
					}
     

			}


		}else
		{
			
			
			$one="Update tblfaqshole SET faqshole_title='$faqshole_title',faqshole_cont='$faqshole_cont' WHERE faqshole_id='$faqshole_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addfaqshole'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addfaqshole'>";
					}
     
			
		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Deletefaqsholepart')
{		
		
					$faqshole_id=$_REQUEST['faqshole_id'];
					$on="select faqshole_img from  tblfaqshole WHERE faqshole_id='$faqshole_id'";
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						$file='img1/faqs/'.$row['faqshole_img'];
						$yes=unlink($file);
					}
					
					
					
					
					$one="DELETE  FROM  tblfaqshole  WHERE faqshole_id='$faqshole_id'";
		
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
					
						echo "Record Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addfaqshole'>";
						
					}
					else
					{
						

						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addfaqshole'>";
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwcontactmiddpart')
{		
		$contactmidd_title=$_REQUEST['contactmidd_title'];
		$contactmidd_cont=$_REQUEST['contactmidd_cont'];
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/contact/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{


			
					$one="insert into tblcontactmidd (contactmidd_img,contactmidd_title,contactmidd_cont) values ('$imagename','$contactmidd_title','$contactmidd_cont')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addcontactmiddle'>";
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addcontactmiddle'>";
					
					}
     

			}


		}

		
	
	
}
?>

<?php


if($_REQUEST['processLogic']=='Editcontactmiddpart')
{		
        $contactmidd_title=$_REQUEST['contactmidd_title'];
		   $contactmidd_cont=$_REQUEST['contactmidd_cont'];
		$contactmidd_id=$_REQUEST['contactmidd_id'];
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/contact/".$imagename;

				

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{
			
					$on="select contactmidd_img from  tblcontactmidd WHERE contactmidd_id='$contactmidd_id'";
				
				$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/contact/'.$row['contactmidd_img'];
						$yes=unlink($file);
					}
			
			
			

					$one="Update tblcontactmidd SET contactmidd_title='$contactmidd_title',contactmidd_cont='$contactmidd_cont',contactmidd_img='$imagename' WHERE contactmidd_id='$contactmidd_id'";
			
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
					    echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addcontactmiddle'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addcontactmiddle'>";
					}
     

			}


		}else
		{
			
			
			
			$one="Update tblcontactmidd SET contactmidd_title='$contactmidd_title',contactmidd_cont='$contactmidd_cont' WHERE contactmidd_id='$contactmidd_id'";
				
			$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully Uploaded Content!";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addcontactmiddle'>";
					}
					else
					{
						

						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addcontactmiddle'>";
					}
     
			
		}

		
	
	
}
?>


<?php


if($_REQUEST['processLogic']=='Deletecontactmiddpart')
{		
		
					$contactmidd_id=$_REQUEST['contactmidd_id'];
					
					$on="select contactmidd_img from  tblcontactmidd WHERE contactmidd_id='$contactmidd_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='img1/contact/'.$row['contactmidd_img'];
						$yes=unlink($file);
					}
			
					
					
					
					
					$one="Delete FROM tblcontactmidd WHERE contactmidd_id='$contactmidd_id'";
				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						
						
						
						echo "Content Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addcontactmiddle'>";
					}
					else
					{
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addcontactmiddle'>";

					
					
					
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwimportanttoppart')
{		
		
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/important/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

					$submission_date= date("Y-m-d");

			
					$one="insert into tblimportanttop (importanttop_img) values ('$imagename')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportanttop'>";
							
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportanttop'>";
					
					}
     

			}


		}

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editimportanttoppart')
{		
		
		
		function GetImageExtension($imagetype)
		{

		if(empty($imagetype)) return false;

			switch($imagetype)
			{

					case 'image/bmp': return '.bmp';

					case 'image/gif': return '.gif';

					case 'image/jpeg': return '.jpg';

					case 'image/png': return '.png';

					default: return false;

			}

		}

		
		if (!empty($_FILES["apply_fileToUpload"]["name"])) 
		{
				$file_name=$_FILES["apply_fileToUpload"]["name"];

				$temp_name=$_FILES["apply_fileToUpload"]["tmp_name"];

				$imgtype=$_FILES["apply_fileToUpload"]["type"];

				$ext= GetImageExtension($imgtype);

				$imagename=uniqid().$file_name;

				$target_path = "../img1/important/".$imagename;

     

 
			if(move_uploaded_file($temp_name, $target_path)) 
			{

				
					$importanttop_id=$_REQUEST['importanttop_id'];
					
					$on="select importanttop_img from  tblimportanttop WHERE importanttop_id='$importanttop_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='../img1/important/'.$row['importanttop_img'];
						$yes=unlink($file);
					}
					
					
					
					$one="Update tblimportanttop SET importanttop_img='$imagename' WHERE importanttop_id='$importanttop_id'";

				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportanttop'>";
					}
					else
					{
					
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportanttop'>";
					}
     

			}


		}

		
	
	
}
?>

<?php


if($_REQUEST['processLogic']=='Deleteimportanttoppart')
{		
		
					$importanttop_id=$_REQUEST['importanttop_id'];
					
					$on="select importanttop_img from  tblimportanttop WHERE importanttop_id='$importanttop_id'";
				
					$tw=mysql_query($on);
					$nrows=mysql_num_rows($tw);
				
					if($nrows >=1)
					{
						$row=mysql_fetch_assoc($tw);
						
						
						$file='img1/important/'.$row['importanttop_img'];
						$yes=unlink($file);
					}
					
					
					
					
					$one="Delete FROM tblimportanttop WHERE importanttop_id='$importanttop_id'";
				
		
					$two=mysql_query($one);
		
					if($two && $yes)
					{	
						
						
						
						
						echo "Content Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addimportanttop'>";
					}
					else
					{
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addimportanttop'>";
					
					
					
					}
     

		


		

		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='AddANewwimportantmiddpart')
{	
	$importantmidd_title=$_REQUEST['importantmidd_title'];
	$importantmidd_link=$_REQUEST['importantmidd_link'];
	$importantmidd_text=$_REQUEST['importantmidd_text'];
	


					$one="insert into tblimportantmidd (importantmidd_title,importantmidd_link,importantmidd_text) values ('$importantmidd_title','$importantmidd_link','$importantmidd_text')";
		
					$two=mysql_query($one);
		
					if($two)
					{	
						
						
						echo "Successfully Uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportantmidd'>";
						
					}
					else
					{
						
						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportantmidd'>";
					
					}
		
		
	
	
}
?>
<?php


if($_REQUEST['processLogic']=='Editimportantmiddpart')
{		

		$importantmidd_title=$_REQUEST['importantmidd_title'];
	$importantmidd_link=$_REQUEST['importantmidd_link'];
	$importantmidd_text=$_REQUEST['importantmidd_text'];
		$importantmidd_id=$_REQUEST['importantmidd_id'];
		
		
					$one="Update tblimportantmidd SET importantmidd_title='$importantmidd_title',importantmidd_link='$importantmidd_link',importantmidd_text='$importantmidd_text' WHERE importantmidd_id='$importantmidd_id'";
			
					$two=mysql_query($one);
		
					if($two)
					{	
						
						echo "Successfully uploaded Content!";	
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportantmidd'>";
					}
					else
					{
						

						
						echo "Faill";
						echo "<meta HTTP-EQUIV='REFRESH' content='3; url=index.php?page=addimportantmidd'>";
					}
}
?>
<?php


if($_REQUEST['processLogic']=='Deleteimportantmiddpart')
{		
		
					$importantmidd_id=$_REQUEST['importantmidd_id'];
					$one="DELETE  FROM  tblimportantmidd  WHERE importantmidd_id='$importantmidd_id'";
		
		
					$two=mysql_query($one);
		
					if($two)
					{	
					
						echo "Record Deleted Successfully";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addimportantmidd'>";
					}
					else
					{
						

						echo "Faill";	
						echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addimportantmidd'>";
					}
     

		


		

		
	
	
}
?>