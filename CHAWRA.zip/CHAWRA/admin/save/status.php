<?php
if($_REQUEST['slieder']=='sliderhhh' && $_REQUEST['idd']!='')
{

		$slider_id=$_REQUEST['idd'];
		$slider_accept=$_REQUEST['aa'];
		
if($slider_accept=='0')
{
$aa=1;	
}
elseif($slider_accept=='1')
{
$aa=0;	
}
else
{
echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addslider&aa=b'>";	
}



$Logic="Update tblslider SET slider_accept='$aa' WHERE slider_id='$slider_id' AND slider_accept='$slider_accept'";
$Place=mysql_query($Logic);

if($Place ) 
{
echo "Success";	
echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addslider'>";
}
else
{
echo "Faill";	
}
}
?>
<?php
if($_REQUEST['event']=='eventhhh' && $_REQUEST['idd']!='')
{

		$event_id=$_REQUEST['idd'];
		$event_accept=$_REQUEST['aa'];
		
if($event_accept=='0')
{
$aa=1;	
}
elseif($event_accept=='1')
{
$aa=0;	
}
else
{
echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addevents&aa=b'>";	
}



$Logic="Update tblevent SET event_accept='$aa' WHERE event_id='$event_id' AND event_accept='$event_accept'";
$Place=mysql_query($Logic);

if($Place ) 
{
echo "Success";	
echo "<meta HTTP-EQUIV='REFRESH' content='0; url=index.php?page=addevents'>";
}
else
{
echo "Faill";	
}
}
?>