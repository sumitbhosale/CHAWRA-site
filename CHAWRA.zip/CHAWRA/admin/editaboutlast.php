
 <?php
$oneList="Select * From tblaboutlast WHERE aboutlast_id='".$_REQUEST['idd']."'";
$twoA=mysql_query($oneList);
if($threeA=mysql_fetch_array($twoA))
{
?>


<div class="widget">
            <div class="widget-header"> 
              <h3>Editing About Page Middle Part</h3>
            </div>
            <div class="widget-content">
                <form method="post" action="save/savedata.php"  class="form-horizontal" id="aboutlastpart_form_edit" enctype="multipart/form-data">
                <input type="hidden" readonly required name="processLogic" value="Editaboutlastpart" /> 
				<input type="hidden" readonly required name="aboutlast_id" value="<?php echo $threeA['aboutlast_id'] ?>"/>                          
  									        
			  
			  
                <fieldset>
				 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Panel Title <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="text" value="<?PHP echo $threeA['aboutlast_pantitle']; ?>" name="aboutlast_pantitle" class="form-control"   >
                    </div>
                    </div>
                  </div>
				 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Image <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="file"  name="apply_fileToUpload" class="form-control"   >
                    </div>
                    </div>
                  </div>
				  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Name of Emp <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                       <input type="text" value="<?PHP echo $threeA['aboutlast_empname']; ?>"  name="aboutlast_empname" class="form-control">
                    </div>
                    </div>
                  </div>
                  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Position of Emp <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
							<input type="text" value="<?PHP echo $threeA['aboutlast_emppos']; ?>" name="aboutlast_emppos" class="form-control">
                    </div>
                    </div>
                  </div>
				  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Proprietor Content<span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
						<textarea class="textarea" style="width: 651px; height: 206px;" name="aboutlast_propcont"><?PHP echo $threeA['aboutlast_propcont']; ?></textarea>
                    </div>
                    </div>
                  </div>
				  
                
                
                </fieldset>
                <div class="form-actions">
                  <button class="btn btn-success" type="submit">Submit</button>
               
                </div>
          </form>
     </div>
</div>  


<?php
  }
?>

<?php
$one="Select * From tblaboutlast";

$two=mysql_query($one);
 while($three=mysql_fetch_array($two))
  {
?>




<div class="modal fade" id="modaldelete<?PHP echo $three['aboutlast_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
       
      </div>
      <div class="modal-body">
	
		 <form method="post" action="index.php?page=save/savedata"  class="form-horizontal"  enctype="multipart/form-data">
                 <input type="hidden" readonly required name="processLogic" value="Deleteaboutlastpart"/> 
				   <input type="hidden" readonly required name="aboutlast_id" value="<?php echo $three['aboutlast_id'] ?>"/>                            
  									        
			  
			  
                <fieldset>
                  <div class="control-group">
                 
               
                    <div class="form-group">
                      
					    <label class="col-lg-12">Do You Really Want to Delete</label>
                    </div>
                 
                  </div>
				  
                
                </fieldset>
                <div class="modal-footer">
						<input type="submit" value="Yes"  class="btn btn-primary"> 
						<button type="button" data-dismiss="modal" class="btn">&nbsp;No&nbsp;&nbsp;</button>
				</div>
          </form>
		
		
		
		
								
      </div>
     
    </div>
  </div>
</div>

<?php
  }
?>

<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
$k('#aboutlastpart_form_edit').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",
rules:{
					aboutlast_pantitle:
					{
					required: true
					},
					aboutlast_empname:
					{
					 required: true	
					},
					aboutlast_emppos:
					{
					 required: true	
					},
					aboutlast_propcont:
					{
					 required: true	
					}
					
                    
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
$('#Success_Popupp').show('slow');

}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 

