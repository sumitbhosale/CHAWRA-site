
 <?php
$oneList="Select * From tblblogmidd WHERE blogmidd_id='".$_REQUEST['idd']."'";
$twoA=mysql_query($oneList);
if($threeA=mysql_fetch_array($twoA))
{
?>


<div class="widget">
            <div class="widget-header"> 
              <h3>Editing Blog Page Middle Part</h3>
            </div>
            <div class="widget-content">
                <form method="post" action="save/savedata.php"  class="form-horizontal" id="blogmiddpart_form_edit" enctype="multipart/form-data">
                <input type="hidden" readonly required name="processLogic" value="Editblogmiddpart" /> 
				<input type="hidden" readonly required name="blogmidd_id" value="<?php echo $threeA['blogmidd_id'] ?>"/>                          
  									        
			  
			  
                <fieldset>
				
			<div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Panel Title <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                       <input type="text"  name="blogmidd_pantitle" value="<?PHP echo $threeA['blogmidd_pantitle']; ?>" class="form-control">
                    </div>
                    </div>
                  </div>
				   <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Blog Title <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                       <input type="text"  name="blogmidd_blogtitle" value="<?PHP echo $threeA['blogmidd_blogtitle']; ?>"  class="form-control">
                    </div>
                    </div>
                  </div>
				  	 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Blog Image <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="file"  name="apply_fileToUpload" class="form-control"   >
                    </div>
                    </div>
                  </div>
                  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Blog Content<span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					  <textarea class="textarea" style="width: 651px; height: 206px;" name="blogmidd_blogcont"><?PHP echo $threeA['blogmidd_blogcont']; ?></textarea>
                    </div>
                    </div>
                  </div>
				  
                </fieldset>
                <div class="form-actions">
                  <button class="btn btn-success" type="submit">Submit</button>
               
                </div>
          </form>
     </div>
</div>  


<?php
  }
?>

<?php
$one="Select * From tblblogmidd";

$two=mysql_query($one);
 while($three=mysql_fetch_array($two))
  {
?>




<div class="modal fade" id="modaldelete<?PHP echo $three['blogmidd_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
       
      </div>
      <div class="modal-body">
	
		 <form method="post" action="index.php?page=save/savedata"  class="form-horizontal"  enctype="multipart/form-data">
                 <input type="hidden" readonly required name="processLogic" value="Deleteblogmiddpart"/> 
				   <input type="hidden" readonly required name="blogmidd_id" value="<?php echo $three['blogmidd_id'] ?>"/>                            
  									        
			  
			  
                <fieldset>
                  <div class="control-group">
                 
               
                    <div class="form-group">
                      
					    <label class="col-lg-12">Do You Really Want to Delete</label>
                    </div>
                 
                  </div>
				  
                
                </fieldset>
                <div class="modal-footer">
						<input type="submit" value="Yes"  class="btn btn-primary"> 
						<button type="button" data-dismiss="modal" class="btn">&nbsp;No&nbsp;&nbsp;</button>
				</div>
          </form>
		
		
		
		
								
      </div>
     
    </div>
  </div>
</div>

<?php
  }
?>

<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
$k('#blogmiddpart_form_edit').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",
rules:{
				
					blogmidd_pantitle:
					{
					required: true
					},
					blogmidd_blogtitle:
					{
					 required: true	
					},
					blogmidd_blogcont:
					{
					 required: true	
					}
                    
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
$('#Success_Popupp').show('slow');

}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 

