<?PHP
include("connect/connect.php");
$mmm="Select * From tbluser WHERE user_type='Super_Admin' AND user_access='1'";
$nnn=mysql_query($mmm);
if(!$ooo=mysql_fetch_array($nnn))
{
$aa="Insert into tbluser(user_name, user_pass, user_email,user_full_name, user_type, user_s_type, user_access) Values ('111', '111', 'Admin@gmail.com', 'CS CHAWRA', 'Super_Admin', 'Administrator', '1')";	
$bb=mysql_query($aa);
}

?>
<!DOCTYPE html>
<html>


<head>
<title>Thin Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="css/bootstrap.css" rel="stylesheet" media="screen">
<link href="css/thin-admin.css" rel="stylesheet" media="screen">
<link href="css/font-awesome.css" rel="stylesheet" media="screen">
<link href="style/style.css" rel="stylesheet">
<link href="style/dashboard.css" rel="stylesheet">
<link href="css/demo_page.css" rel="stylesheet">
<link href="css/demo_table.css" rel="stylesheet">
<link rel='stylesheet' type='text/css' href='assets/jquery-fileupload/css/jquery.fileupload-ui.css' /> 
<link rel="stylesheet" href="style/screen.css" media="screen"/>
<link rel="stylesheet" href="style/lightbox.css" media="screen"/>
</head>
<body>
<div class="login-logo">
	<img src="images/logo.png" width="147" height="33"> 
    </div>

<div class="widget">
<div class="login-content">
  <div class="widget-content" style="padding-bottom:0;">

  <form action="index.php" method="post" enctype="multipart/form-data" class="no-margin">
  <input type="hidden" name="process" readonly required value="TryMeNowww">
  	<input type="hidden" name="processNoee" readonly required value="TryFfloggINN">
                <h3 class="form-title">Login to your account</h3>
                
                <fieldset>
                    <div class="form-group no-margin">
                        <label for="email">Enter your username</label>

                        <div class="input-group input-group-lg">
                                <span class="input-group-addon">
                                    <i class="icon-user"></i>
                                </span>
							<input type="text" name="user_name" placeholder="Username" class="form-control"  id="email" required/>
                        </div>

                    </div>

                    <div class="form-group">
                        <label for="password">Enter your Password</label>

                        <div class="input-group input-group-lg">
                                <span class="input-group-addon">
                                    <i class="icon-lock"></i>
                                </span>
               
							  <input type="password" name="user_pass"   placeholder="Password" class="form-control input-lg"  id="password" required/>
                        </div>

                    </div>
                </fieldset>
               <div class="form-actions">
			
				<button class="btn btn-warning pull-right" type="submit">
				Login <i class="m-icon-swapright m-icon-white"></i>
				</button> 
                <div class="forgot"><a href="#" class="forgot"></a></div>           
			</div>
            
            
            </form>
  
  
  </div>
   </div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery.js"></script> 

<script src="js/bootstrap.min.js"></script> 
<script type="text/javascript" src="js/smooth-sliding-menu.js"></script> 
<script class="include" type="text/javascript" src="javascript/jquery191.min.js"></script> 
<script class="include" type="text/javascript" src="javascript/jquery.jqplot.min.js"></script> 
<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
<script src="assets/sparkline/jquery.sparkline.js" type="text/javascript"></script>
<script src="assets/sparkline/jquery.customSelect.min.js" ></script>
<script src="assets/sparkline/sparkline-chart.js"></script>
<script src="assets/sparkline/easy-pie-chart.js"></script>
<script src="js/select-checkbox.js"></script> 
<script src="js/to-do-admin.js"></script> 


<script type='text/javascript' src='assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-parsley/parsley.min.js'></script> 
<script type='text/javascript' src='assets/js/demo-formvalidation.js'></script> 



<script src="assets/wizard-js/jquery-latest.js"></script> 

<div class="demo_changer active" style="right: 0px;">
                <div class="demo-icon"></div>
                <div class="form_holder">
                        

                    <div class="predefined_styles">
                        <a class="styleswitch" rel="a" href="#"><img alt="" src="images/a.jpg"></a>	
                        <a class="styleswitch" rel="b" href="#"><img alt="" src="images/b.jpg"></a>
                        <a class="styleswitch" rel="c" href="#"><img alt="" src="images/c.jpg"></a>
                        <a class="styleswitch" rel="d" href="#"><img alt="" src="images/d.jpg"></a>
                        <a class="styleswitch" rel="e" href="#"><img alt="" src="images/e.jpg"></a>
                        <a class="styleswitch" rel="f" href="#"><img alt="" src="images/f.jpg"></a>
                        <a class="styleswitch" rel="g" href="#"><img alt="" src="images/g.jpg"></a>
                        <a class="styleswitch" rel="h" href="#"><img alt="" src="images/h.jpg"></a>
                        <a class="styleswitch" rel="i" href="#"><img alt="" src="images/i.jpg"></a>
                        <a class="styleswitch" rel="j" href="#"><img alt="" src="images/j.jpg"></a>
                    </div>
					                    
                </div>
            </div>
<script src="assets/switcher/switcher.js"></script> 
<script src="assets/switcher/moderziner.custom.js"></script>
<link href="assets/switcher/switcher.css" rel="stylesheet">
<link href="assets/switcher/switcher-defult.css" rel="stylesheet">
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/a.css" title="a" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/b.css" title="b" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/c.css" title="c" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/d.css" title="d" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/e.css" title="e" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/f.css" title="f" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/g.css" title="g" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/h.css" title="h" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/i.css" title="i" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/j.css" title="j" media="all" />





<script id="template-upload" type="text/x-tmpl">
    {% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-upload fade">
        <td>
            <span class="preview"></span>
        </td>
        <td>
            <p class="name">{%=file.name%}</p>
            {% if (file.error) { %}
            <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <p class="size">{%=o.formatFileSize(file.size)%}</p>
            {% if (!o.files.error) { %}
            <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100"
                 aria-valuenow="0">
                <div class="progress-bar progress-bar-success" style="width:0%;"></div>
            </div>
            {% } %}
        </td>
        <td>
            {% if (!o.files.error && !i && !o.options.autoUpload) { %}
            <button class="btn btn-primary start">
                <i class="icon-upload"></i>
                <span>Start</span>
            </button>
            {% } %}
            {% if (!i) { %}
            <button class="btn btn-warning cancel">
                <i class="icon-ban-circle"></i>
                <span>Cancel</span>
            </button>
            {% } %}
        </td>
    </tr>
    {% } %}
</script>

<!-- The template to display files available for download -->
<script id="template-download" type="text/x-tmpl">
    {% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-download fade">
        <td>
<span class="preview">
    {% if (file.thumbnailUrl) { %}
        <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" data-gallery><img
                src="{%=file.thumbnailUrl%}"></a>
    {% } %}
</span>
        </td>
        <td>
            <p class="name">
                {% if (file.url) { %}
                <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}">
                    {%=file.thumbnailUrl?'data-gallery':''%}>{%=file.name%}</a>
                {% } else { %}
                <span>{%=file.name%}</span>
                {% } %}
            </p>
            {% if (file.error) { %}
            <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <span class="size">{%=o.formatFileSize(file.size)%}</span>
        </td>
        <td>
            {% if (file.deleteUrl) { %}
            <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}">{% if
                (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}
                <i class="icon-trash "></i>
                <span>Delete</span>
            </button>
            <input type="checkbox" name="delete" value="1" class="toggle">
            {% } else { %}
            <button class="btn btn-warning cancel">
                <i class="icon-ban-circle"></i>
                <span>Cancel</span>
            </button>
            {% } %}
        </td>
    </tr>
    {% } %}
</script>
<script type='text/javascript' src='javascript/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/vendor/jquery.ui.widget.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/tmpl.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/load-image.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/canvas-to-blob.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.blueimp-gallery.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-process.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-image.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-audio.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-video.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-validate.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-ui.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/main.js'></script> 
<script src="javascript/lightbox-2.6.min.js"></script> 
<script>
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-2196019-1']);
	_gaq.push(['_trackPageview']);

	(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
	</script>
<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example').dataTable( {
					"sPaginationType": "full_numbers"
				} );
			} );
</script>


</body>



</html>





