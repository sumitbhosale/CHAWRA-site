

<div class="wrapper">
  <div class="page-content">
    <div class="content container">
     
      <div class="row">
        <div class="col-lg-12">
          <div class="widget">
            <div class="widget-header"> <i class="icon-table"></i>
              <h3>Blog Page Middle Part </h3>
			   <div class="btn-group">
						<a class="accordion-toggle btn btn-xs minimize-box" data-toggle="collapse"
							href="#collapseOne">
						   
						</a>
					  
						<button type="button" class="btn btn-right-icon btn-danger"  id="ListButton">
						<i class="fa fa-tasks"></i>Blog Page Middle Part List</button>
						<button type="button"   style="display:none" class="btn btn-right-icon btn-success" id="AddButton">
						<i class="fa fa-inbox"></i>Add Blog Page Middle Part</button>
			   </div>
			</div>
            <div class="widget-content">
         
<div class="example_alt_pagination">
      <div id="container">
        <div class="full_width big"></div>
  <div id="Listt">
    <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
      <thead>
        <tr>
          <th>Sr.</th>		
		  <th>Panel Title</th>
          <th>Blog Title</th>
		  <th>Blog Image</th>
		  <th>Blog Content</th>
          <th>Edit</th>
          <th>Delete</th>
          </tr>
        </thead>
      <tbody>
	  <?php
			$i=0;
			$one="Select * From tblblogmidd";
			$two=mysql_query($one);
			while($three=mysql_fetch_array($two))
			{
		$i=$i+1;
	   ?>
        <tr class="gradeX">
          <td><?php echo $i; ?></td>
		  
		   <td>
          	<?php echo $three['blogmidd_pantitle']; ?>
          </td>
          <td>
          	<?php echo $three['blogmidd_blogtitle']; ?>
          </td>
		  <td>
           <img style="height:60px; width:60px;" src="img1/blog/<?php echo $three['blogmidd_blogimg']; ?>" />
          </td>
		
		  <td>
          	<?php echo $three['blogmidd_blogcont']; ?>
          </td>
          <td><a href="index.php?page=editblogmiddle&idd=<?PHP echo $three['blogmidd_id']; ?>">Edit</a></td>							
          <td><a href="#"  data-toggle="modal" data-target="#modaldelete<?PHP echo $three['blogmidd_id']; ?>">Delete</a></td>
        </tr>
		<?PHP } ?>
        </tbody>
      <tfoot>
        <tr>
          <th> </th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
		  <th></th>
		  <th></th>
          </tr>
        </tfoot>
  </table>
    </div>
    <div class="widget" id="Formss" style="display:none">
            <div class="widget-header"> 
              <h3>Add Blog Page Middle Part</h3>
            </div>
            <div class="widget-content">
			 
              <form method="post" action="save/savedata.php" class="form-horizontal" id="blogmiddpart_form"  enctype="multipart/form-data">
			  
			  <input type="hidden" readonly required name="processLogic" value="AddANewwblogmiddpart" /> 
			  
                <fieldset>
				
				  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Panel Title <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                       <input type="text"  name="blogmidd_pantitle" class="form-control">
                    </div>
                    </div>
                  </div>
				   <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Blog Title <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                       <input type="text"  name="blogmidd_blogtitle" class="form-control">
                    </div>
                    </div>
                  </div>
				  	 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Blog Image <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="file"  name="apply_fileToUpload" class="form-control"   >
                    </div>
                    </div>
                  </div>
                  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Blog Content<span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					  <textarea class="textarea" style="width: 651px; height: 206px;" name="blogmidd_blogcont"></textarea>
                    </div>
                    </div>
                  </div>
				  
                
                </fieldset>
                <div class="form-actions">
                  <button class="btn btn-success" type="submit">Submit</button>
               
                </div>
              </form>
            </div>
          </div>  
        
      
        </div>
    </div>
    
    
            </div>
          </div>
        </div>
      </div>
      
      
      
      
      
    </div>
  </div>
</div>
</div>






<script type="text/javascript">
$("#ListButton, #AddButton").click(function() {
  $("#Formss, #Listt").slideToggle( "slow" );
  $("#ListButton, #AddButton").fadeToggle();
});
</script>






<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
$k('#blogmiddpart_form').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",

rules:{
					apply_fileToUpload:
					{
					required: true
					},
					blogmidd_pantitle:
					{
					required: true
					},
					blogmidd_blogtitle:
					{
					 required: true	
					},
					blogmidd_blogcont:
					{
					 required: true	
					}
                    
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
$('#Success_Popupp').show('slow');
}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 



<?PHP include('editblogmiddle.php'); ?>





