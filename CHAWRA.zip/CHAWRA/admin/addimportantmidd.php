

<div class="wrapper">
  <div class="page-content">
    <div class="content container">
     
      <div class="row">
        <div class="col-lg-12">
          <div class="widget">
            <div class="widget-header"> <i class="icon-table"></i>
              <h3>Important Page Mid Part </h3>
			   <div class="btn-group">
						<a class="accordion-toggle btn btn-xs minimize-box" data-toggle="collapse"
							href="#collapseOne">
						   
						</a>
					  
						<button type="button" class="btn btn-right-icon btn-danger"  id="ListButton">
						<i class="fa fa-tasks"></i>Important Page Mid Part List</button>
						<button type="button"   style="display:none" class="btn btn-right-icon btn-success" id="AddButton">
						<i class="fa fa-inbox"></i>Add Important Page Mid Part</button>
			   </div>
			</div>
            <div class="widget-content">
         
<div class="example_alt_pagination">
      <div id="container">
        <div class="full_width big"></div>
  <div id="Listt">
    <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
      <thead>
        <tr>
          <th>Sr.</th>
		  <th>Important Link Panel Title </th>	 
		  <th>Important Link</th>	 
		  <th>Important Text</th>	 
          <th>Edit</th>
          <th>Delete</th>
          </tr>
        </thead>
      <tbody>
	  <?php
			$i=0;
			$one="Select * From tblimportantmidd";
			$two=mysql_query($one);
			while($three=mysql_fetch_array($two))
			{
		$i=$i+1;
	   ?>
        <tr class="gradeX">
          <td><?php echo $i; ?></td>
		  <td>
          <?php echo $three['importantmidd_title']; ?>
          </td>
		   
		  <td>
          <?php echo $three['importantmidd_link']; ?>
          </td>
		  
		  <td>
          <?php echo $three['importantmidd_text']; ?>
          </td>
		
		
          <td><a href="index.php?page=editimportantmidd&idd=<?PHP echo $three['importantmidd_id']; ?>">Edit</a></td>							
          <td><a href="#"  data-toggle="modal" data-target="#modaldelete<?PHP echo $three['importantmidd_id']; ?>">Delete</a></td>
        </tr>
		<?PHP } ?>
        </tbody>
      <tfoot>
        <tr>
          <th> </th>
          <th></th>
          <th></th>
          <th></th>
		  <th></th>
		   <th></th>
          </tr>
        </tfoot>
  </table>
    </div>
    <div class="widget" id="Formss" style="display:none">
            <div class="widget-header"> 
              <h3>Add Important Page Mid Part</h3>
            </div>
            <div class="widget-content">
			 
              <form method="post" action="save/savedata.php" class="form-horizontal" id="importantmiddpart_form"  enctype="multipart/form-data">
			  
			  <input type="hidden" readonly required name="processLogic" value="AddANewwimportantmiddpart" /> 
			  
                <fieldset>
				 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Panel Title<span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="text"  name="importantmidd_title" class="form-control"   >
                    </div>
                    </div>
                  </div>
				
				 	  	 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Link For Text <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="url"  name="importantmidd_link" class="form-control"   >
                    </div>
                    </div>
                  </div>
				 
					 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Text For Link<span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="text"  name="importantmidd_text" class="form-control"   >
                    </div>
                    </div>
                  </div>
				 
                
				  
                
                </fieldset>
                <div class="form-actions">
                  <button class="btn btn-success" type="submit">Submit</button>
               
                </div>
              </form>
            </div>
          </div>  
        
      
        </div>
    </div>
    
    
            </div>
          </div>
        </div>
      </div>
      
      
      
      
      
    </div>
  </div>
</div>
</div>






<script type="text/javascript">
$("#ListButton, #AddButton").click(function() {
  $("#Formss, #Listt").slideToggle( "slow" );
  $("#ListButton, #AddButton").fadeToggle();
});
</script>






<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
$k('#importantmiddpart_form').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",

rules:{
					importantmidd_title:
					{
					required: true
					},
					importantmidd_link:
					{
					required: true
					},
					importantmidd_text:
					{
					required: true
					}
					
                    
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
$('#Success_Popupp').show('slow');
}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 


<?PHP include('editimportantmidd.php'); ?>





