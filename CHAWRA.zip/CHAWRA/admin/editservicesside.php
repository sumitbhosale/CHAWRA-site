
 <?php
$oneList="Select * From tblserviceside WHERE serviceside_id='".$_REQUEST['idd']."'";
$twoA=mysql_query($oneList);
if($threeA=mysql_fetch_array($twoA))
{
?>


<div class="widget">
            <div class="widget-header"> 
              <h3>Editing Services Page Side Part</h3>
            </div>
            <div class="widget-content">
                <form method="post" action="save/savedata.php"  class="form-horizontal" id="servicessidepart_form_edit" enctype="multipart/form-data">
                <input type="hidden" readonly required name="processLogic" value="Editservicessidepart" /> 
				<input type="hidden" readonly required name="serviceside_id" value="<?php echo $threeA['serviceside_id'] ?>"/>                          
  									        
			  
			  
                <fieldset>
				 	 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Link For Image <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="url"  value="<?php echo $threeA['serviceside_link']; ?>" name="serviceside_link" class="form-control"   >
                    </div>
                    </div>
                  </div>
				 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Image <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="file"  name="apply_fileToUpload" class="form-control"   >
                    </div>
                    </div>
                  </div>
				 
				   
				
          
				  
                
                </fieldset>
                <div class="form-actions">
                  <button class="btn btn-success" type="submit">Submit</button>
               
                </div>
          </form>
     </div>
</div>  


<?php
  }
?>

<?php
$one="Select * From tblserviceside";

$two=mysql_query($one);
 while($three=mysql_fetch_array($two))
  {
?>




<div class="modal fade" id="modaldelete<?PHP echo $three['serviceside_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
       
      </div>
      <div class="modal-body">
	
		 <form method="post" action="index.php?page=save/savedata"  class="form-horizontal"  enctype="multipart/form-data">
                 <input type="hidden" readonly required name="processLogic" value="Deleteservicessidepart"/> 
				   <input type="hidden" readonly required name="serviceside_id" value="<?php echo $three['serviceside_id'] ?>"/>                            
  									        
			  
			  
                <fieldset>
                  <div class="control-group">
                 
               
                    <div class="form-group">
                      
					    <label class="col-lg-12">Do You Really Want to Delete</label>
                    </div>
                 
                  </div>
				  
                
                </fieldset>
                <div class="modal-footer">
						<input type="submit" value="Yes"  class="btn btn-primary"> 
						<button type="button" data-dismiss="modal" class="btn">&nbsp;No&nbsp;&nbsp;</button>
				</div>
          </form>
		
		
		
		
								
      </div>
     
    </div>
  </div>
</div>

<?php
  }
?>

<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
$k('#servicessidepart_form_edit').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",
rules:{
				
					serviceside_link:
					{
					required: true
					}
					
					
                    
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
$('#Success_Popupp').show('slow');

}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 

