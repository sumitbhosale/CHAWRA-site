
 <?php
$oneList="Select * From tblimportanttop WHERE importanttop_id='".$_REQUEST['idd']."'";
$twoA=mysql_query($oneList);
if($threeA=mysql_fetch_array($twoA))
{
?>


<div class="widget">
            <div class="widget-header"> 
              <h3>Editing Important Page Top Part</h3>
            </div>
            <div class="widget-content">
                <form method="post" action="save/savedata.php"  class="form-horizontal" id="importanttoppart_form_edit" enctype="multipart/form-data">
                <input type="hidden" readonly required name="processLogic" value="Editimportanttoppart" /> 
				<input type="hidden" readonly required name="importanttop_id" value="<?php echo $threeA['importanttop_id'] ?>"/>                          
  									        
			  
			  
                <fieldset>
				
				 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Image <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="file"  name="apply_fileToUpload" class="form-control"   >
                    </div>
                    </div>
                  </div>
			
                
                </fieldset>
                <div class="form-actions">
                  <button class="btn btn-success" type="submit">Submit</button>
               
                </div>
          </form>
     </div>
</div>  


<?php
  }
?>

<?php
$one="Select * From tblimportanttop";

$two=mysql_query($one);
 while($three=mysql_fetch_array($two))
  {
?>




<div class="modal fade" id="modaldelete<?PHP echo $three['importanttop_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
       
      </div>
      <div class="modal-body">
	
		 <form method="post" action="index.php?page=save/savedata"  class="form-horizontal"  enctype="multipart/form-data">
                 <input type="hidden" readonly required name="processLogic" value="Deleteimportanttoppart"/> 
				   <input type="hidden" readonly required name="importanttop_id" value="<?php echo $three['importanttop_id'] ?>"/>                            
  									        
			  
			  
                <fieldset>
                  <div class="control-group">
                 
               
                    <div class="form-group">
                      
					    <label class="col-lg-12">Do You Really Want to Delete</label>
                    </div>
                 
                  </div>
				  
                
                </fieldset>
                <div class="modal-footer">
						<input type="submit" value="Yes"  class="btn btn-primary"> 
						<button type="button" data-dismiss="modal" class="btn">&nbsp;No&nbsp;&nbsp;</button>
				</div>
          </form>
		
		
		
		
								
      </div>
     
    </div>
  </div>
</div>

<?php
  }
?>

<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
$k('#importanttoppart_form_edit').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",
rules:{
	
					apply_fileToUpload:
					{
					 required: true	
					}
                    
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
$('#Success_Popupp').show('slow');

}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 

