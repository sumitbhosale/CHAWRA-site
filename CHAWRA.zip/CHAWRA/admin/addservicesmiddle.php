

<div class="wrapper">
  <div class="page-content">
    <div class="content container">
     
      <div class="row">
        <div class="col-lg-12">
          <div class="widget">
            <div class="widget-header"> <i class="icon-table"></i>
              <h3>Services Page Middle Part </h3>
			   <div class="btn-group">
						<a class="accordion-toggle btn btn-xs minimize-box" data-toggle="collapse"
							href="#collapseOne">
						   
						</a>
					  
						<button type="button" class="btn btn-right-icon btn-danger"  id="ListButton">
						<i class="fa fa-tasks"></i>Services Page Middle Part List</button>
						<button type="button"   style="display:none" class="btn btn-right-icon btn-success" id="AddButton">
						<i class="fa fa-inbox"></i>Add Services Page Middle Part</button>
			   </div>
			</div>
            <div class="widget-content">
         
<div class="example_alt_pagination">
      <div id="container">
        <div class="full_width big"></div>
  <div id="Listt">
    <table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
      <thead>
        <tr>
          <th>Sr.</th>		
		  <th>Panel Title</th>
          <th>Service Title</th>
		  <th>Service Image</th>
		  <th>Service Content</th>
          <th>Edit</th>
          <th>Delete</th>
          </tr>
        </thead>
      <tbody>
	  <?php
			$i=0;
			$one="Select * From tblservicemidd";
			$two=mysql_query($one);
			while($three=mysql_fetch_array($two))
			{
		$i=$i+1;
	   ?>
        <tr class="gradeX">
          <td><?php echo $i; ?></td>
		  
		   <td>
          	<?php echo $three['servicemidd_pantitle']; ?>
          </td>
          <td>
          	<?php echo $three['servicemidd_servicetitle']; ?>
          </td>
		  <td>
           <img style="height:60px; width:60px;" src="img1/services/<?php echo $three['servicemidd_serviceimg']; ?>" />
          </td>
		
		  <td>
          	<?php echo $three['servicemidd_servicecont']; ?>
          </td>
          <td><a href="index.php?page=editservicesmiddle&idd=<?PHP echo $three['servicemidd_id']; ?>">Edit</a></td>							
          <td><a href="#"  data-toggle="modal" data-target="#modaldelete<?PHP echo $three['servicemidd_id']; ?>">Delete</a></td>
        </tr>
		<?PHP } ?>
        </tbody>
      <tfoot>
        <tr>
          <th> </th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
		  <th></th>
		  <th></th>
          </tr>
        </tfoot>
  </table>
    </div>
    <div class="widget" id="Formss" style="display:none">
            <div class="widget-header"> 
              <h3>Add Services Page Middle Part</h3>
            </div>
            <div class="widget-content">
			 
              <form method="post" action="save/savedata.php" class="form-horizontal" id="servicesmiddpart_form"  enctype="multipart/form-data">
			  
			  <input type="hidden" readonly required name="processLogic" value="AddANewwservicemiddpart" /> 
			  
                <fieldset>
				
				  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Panel Title <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                       <input type="text"  name="servicemidd_pantitle" class="form-control">
                    </div>
                    </div>
                  </div>
				   <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Service Title <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                       <input type="text"  name="servicemidd_servicetitle" class="form-control">
                    </div>
                    </div>
                  </div>
				  	 <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Service Image <span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					   <input type="file"  name="apply_fileToUpload" class="form-control"   >
                    </div>
                    </div>
                  </div>
                  <div class="control-group">
                  <div class="col-md-3">
                    <label class="control-label" for="title">Service Content<span class="required">*</span></label>
                    </div>
                    <div class="col-md-9">
                    <div class="form-group">
                      
					  <textarea class="textarea" style="width: 651px; height: 206px;" name="servicemidd_servicecont"></textarea>
                    </div>
                    </div>
                  </div>
				  
                
                </fieldset>
                <div class="form-actions">
                  <button class="btn btn-success" type="submit">Submit</button>
               
                </div>
              </form>
            </div>
          </div>  
        
      
        </div>
    </div>
    
    
            </div>
          </div>
        </div>
      </div>
      
      
      
      
      
    </div>
  </div>
</div>
</div>






<script type="text/javascript">
$("#ListButton, #AddButton").click(function() {
  $("#Formss, #Listt").slideToggle( "slow" );
  $("#ListButton, #AddButton").fadeToggle();
});
</script>






<script type="text/javascript" src="js/jquery.js"></script> 
<script>
var $k = jQuery.noConflict();
</script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script>  
   
<script type="text/javascript">
$k('#servicesmiddpart_form').validate({
//errorLabelContainer: "#error-note",
//wrapper: "li",

rules:{
					apply_fileToUpload:
					{
					required: true
					},
					servicemidd_pantitle:
					{
					required: true
					},
					servicemidd_servicetitle:
					{
					 required: true	
					},
					servicemidd_servicecont:
					{
					 required: true	
					}
                    
	},
submitHandler: function(form){
$k(form).ajaxSubmit({
target: '#Success_Msgg', 
success: function() 
{ 
$('#Success_Popupp').show('slow');
}, 
error: function() 
{
alert('bbbb')
}
}); 

}


});
</script> 




<?PHP include('editservicesmiddle.php'); ?>





