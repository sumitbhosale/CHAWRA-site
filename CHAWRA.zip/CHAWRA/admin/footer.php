
<div class="bottom-nav footer"> 2015&copy; Thin Admin by Logic Palace Systems & Softwares. </div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 


<script type="text/javascript" src="js/smooth-sliding-menu.js"></script> 
<script class="include" type="text/javascript" src="javascript/jquery191.min.js"></script> 
<script class="include" type="text/javascript" src="javascript/jquery.jqplot.min.js"></script> 
<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
<script src="assets/sparkline/jquery.sparkline.js" type="text/javascript"></script>
<script src="assets/sparkline/jquery.customSelect.min.js" ></script>
<script src="assets/sparkline/sparkline-chart.js"></script>
<script src="assets/sparkline/easy-pie-chart.js"></script>
<script src="js/select-checkbox.js"></script> 
<script src="js/to-do-admin.js"></script> 


<script type='text/javascript' src='assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-parsley/parsley.min.js'></script> 
<script type='text/javascript' src='assets/js/demo-formvalidation.js'></script> 



<script src="assets/wizard-js/jquery-latest.js"></script> 

<div class="demo_changer active" style="right: 0px;">
                <div class="demo-icon"></div>
                <div class="form_holder">
                        

                    <div class="predefined_styles">
                        <a class="styleswitch" rel="a" href="#"><img alt="" src="images/a.jpg"></a>	
                        <a class="styleswitch" rel="b" href="#"><img alt="" src="images/b.jpg"></a>
                        <a class="styleswitch" rel="c" href="#"><img alt="" src="images/c.jpg"></a>
                        <a class="styleswitch" rel="d" href="#"><img alt="" src="images/d.jpg"></a>
                        <a class="styleswitch" rel="e" href="#"><img alt="" src="images/e.jpg"></a>
                        <a class="styleswitch" rel="f" href="#"><img alt="" src="images/f.jpg"></a>
                        <a class="styleswitch" rel="g" href="#"><img alt="" src="images/g.jpg"></a>
                        <a class="styleswitch" rel="h" href="#"><img alt="" src="images/h.jpg"></a>
                        <a class="styleswitch" rel="i" href="#"><img alt="" src="images/i.jpg"></a>
                        <a class="styleswitch" rel="j" href="#"><img alt="" src="images/j.jpg"></a>
                    </div>
					                    
                </div>
            </div>
<script src="assets/switcher/switcher.js"></script> 
<script src="assets/switcher/moderziner.custom.js"></script>
<link href="assets/switcher/switcher.css" rel="stylesheet">
<link href="assets/switcher/switcher-defult.css" rel="stylesheet">
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/a.css" title="a" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/b.css" title="b" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/c.css" title="c" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/d.css" title="d" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/e.css" title="e" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/f.css" title="f" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/g.css" title="g" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/h.css" title="h" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/i.css" title="i" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/j.css" title="j" media="all" />





<script id="template-upload" type="text/x-tmpl">
    {% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-upload fade">
        <td>
            <span class="preview"></span>
        </td>
        <td>
            <p class="name">{%=file.name%}</p>
            {% if (file.error) { %}
            <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <p class="size">{%=o.formatFileSize(file.size)%}</p>
            {% if (!o.files.error) { %}
            <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100"
                 aria-valuenow="0">
                <div class="progress-bar progress-bar-success" style="width:0%;"></div>
            </div>
            {% } %}
        </td>
        <td>
            {% if (!o.files.error && !i && !o.options.autoUpload) { %}
            <button class="btn btn-primary start">
                <i class="icon-upload"></i>
                <span>Start</span>
            </button>
            {% } %}
            {% if (!i) { %}
            <button class="btn btn-warning cancel">
                <i class="icon-ban-circle"></i>
                <span>Cancel</span>
            </button>
            {% } %}
        </td>
    </tr>
    {% } %}
</script>

<!-- The template to display files available for download -->
<script id="template-download" type="text/x-tmpl">
    {% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-download fade">
        <td>
<span class="preview">
    {% if (file.thumbnailUrl) { %}
        <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" data-gallery><img
                src="{%=file.thumbnailUrl%}"></a>
    {% } %}
</span>
        </td>
        <td>
            <p class="name">
                {% if (file.url) { %}
                <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}">
                    {%=file.thumbnailUrl?'data-gallery':''%}>{%=file.name%}</a>
                {% } else { %}
                <span>{%=file.name%}</span>
                {% } %}
            </p>
            {% if (file.error) { %}
            <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <span class="size">{%=o.formatFileSize(file.size)%}</span>
        </td>
        <td>
            {% if (file.deleteUrl) { %}
            <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}">{% if
                (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}
                <i class="icon-trash "></i>
                <span>Delete</span>
            </button>
            <input type="checkbox" name="delete" value="1" class="toggle">
            {% } else { %}
            <button class="btn btn-warning cancel">
                <i class="icon-ban-circle"></i>
                <span>Cancel</span>
            </button>
            {% } %}
        </td>
    </tr>
    {% } %}
</script>
<script type='text/javascript' src='javascript/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/vendor/jquery.ui.widget.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/tmpl.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/load-image.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/canvas-to-blob.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.blueimp-gallery.min.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-process.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-image.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-audio.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-video.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-validate.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/jquery.fileupload-ui.js'></script> 
<script type='text/javascript' src='assets/jquery-fileupload/js/main.js'></script> 
<script src="javascript/lightbox-2.6.min.js"></script> 
<script>
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-2196019-1']);
	_gaq.push(['_trackPageview']);

	(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
	</script>
<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8">
			$(document).ready(function() {
				$('#example').dataTable( {
					"sPaginationType": "full_numbers"
				} );
			} );
</script>

<script src="js/wysihtml5-0.3.0.js"></script>
<script src="js/prettify.js"></script>
<script src="js/bootstrap-wysihtml5.js"></script>


<script>
	$('.textarea').wysihtml5();
</script>

<script type="text/javascript" charset="utf-8">
	$(prettyPrint);
</script>



</body>



</html>
