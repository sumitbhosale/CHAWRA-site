    <!-- Main Container -->

    <div id="banners"></div>
    <div class="container">
		 <?php
									$one="Select * From tblservicetop LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
		<div class="row container-kamn wow zoomIn">
			<img src="admin/img1/services/<?php echo $three['servicetop_img']; ?>" class="blog-post"  alt="Feature-img" align="right" height="300px" width="100%"> 
		</div>	
		<?PHP   } ?>
		<div class="panel panel-default">
		<?php
									$one="Select * From tblservicemidd LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
				<div class="panel-heading" style="background:#99AABF;font-size:21px;color:#2D476F"><?php echo $three['servicemidd_pantitle']; ?></div>
				<?php } ?>
					<div class="panel-body" style="background-color:#F1F1F1" >
		
		<div class="col-md-9">
			<?php
			$j='A';
									$one="Select * From tblservicemidd  LIMIT 6";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
        <div class="row">
            <div class="col-md-12">
                <div  <?PHP if($j=='A') { ?> class="blockquote-info animated wow fadeInLeft clearfix" <?PHP $j='B';}else{ ?>class="blockquote-info animated wow fadeInRight clearfix" <?php $j='A';}?> >
					<div class="row"><h3><?php echo $three['servicemidd_servicetitle']; ?></h3><hr></div>
                    <div class="col-md-6">
					    
                        <img src="admin/img1/services/<?php echo $three['servicemidd_serviceimg']; ?>"   class="img-aa"  alt="Feature-img" style="height:200px;width:100%" >
						
					</div>
                   
                    <div class="col-md-6">
					<?php echo $three['servicemidd_servicecont']; ?>

                    </div>
                </div>
            </div>
  
        </div></br>
			<?php } ?>
		

		</div>
		<div class="col-md-3" style="margin-top:60px;">
				<?php
									$one="Select * From tblserviceside LIMIT 4";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
			<a href="<?php echo $three['serviceside_link']; ?>" target="_blank"> 	<img src="admin/img1/services/<?php echo $three['serviceside_img']; ?>"   alt="Feature-img" align="right" style="height:430px" width="100%" data-wow-delay="1.2s" class="blog-image wow fadeInDown"></a>
                
				<?php } ?>
		</div>
	</div>
	
</div>
</div>
    <!--End Main Container -->