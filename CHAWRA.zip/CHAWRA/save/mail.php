<?php 
	
		
		$to="bhosalesumit92@gmail.com";
		$from = "contact@dummy.co.in";
		$subject="".$apply_name."Contact With Us ";
		$headers  = "From: $from\r\n"; 
		$headers .= "Content-type: text/html\r\n";
		$header="From:".$apply_name."\r\n";
		$message="Contact Us Details.\r\n";
		$message.="Name:".$apply_name."\r\n";
		$message.="Mobile:".$apply_mob."\r\n";
		$message.="Email: ".$apply_email."\r\n";
		$message.="Message: ".$apply_message."\r\n";
		$message.="Message: ".$message." \r\n";

		$sentmail = mail($to,$subject,$message,$header);
		
		

		
		
?>