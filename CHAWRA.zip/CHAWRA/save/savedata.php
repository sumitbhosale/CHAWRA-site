

<?php


if($_REQUEST['process']=='AddNewcontacts')
{		$apply_name=$_REQUEST['apply_name'];
		$apply_email=$_REQUEST['apply_email'];
		$apply_mob=$_REQUEST['apply_mob'];
		$apply_message=$_REQUEST['apply_message'];
	
		include("mail.php");	
		echo "Thank You.. For Your Enqury ..!";
}
?>