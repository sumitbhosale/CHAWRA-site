
    <!-- Footer -->
    <footer> 
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h3><i class="fa fa-map-marker"></i> Contact:</h3>
                    <p class="footer-contact">
                        <b>Head Office:-</b></br>
                       Office No 3B, First Floor,
					   Mahalaxmi Heights,
					   Near Hotel Keys, Pimpri,
					   Pune -411018<br></br>
                    </p>
                </div>
                <div class="col-md-3">
                    <h3><i class="fa fa-external-link"></i> Links</h3>
                    <p> <a href="index.php?page=about"> About ( Who we are )</a></p>
                    <p> <a href="index.php?page=services"> Services ( What we do )</a></p>
                    <p> <a href="index.php?page=blog">Blog</a></p>
                     
                </div>
				 <div class="col-md-3">
                    <h3><i class="fa fa-external-link"></i> Links</h3>
                    <p> <a href="index.php?page=important">Important Links</a></p>
                    <p> <a href="index.php?page=faqs">Faqs</a></p>
                    <p> <a href="index.php?page=contact">Contact</a></p>
                    
                </div>
              <div class="col-md-3">
                <h3><i class="fa fa-heart"></i> Socialize</h3>
                <div id="social-icons">
                    <a href="https://accounts.google.com" target="_blank" class="btn-group google-plus">
                        <i class="fa fa-google-plus"></i>
                    </a>
                      <a href="https://in.linkedin.com/" target="_blank" class="btn-group linkedin">
                        <i class="fa fa-linkedin-square"></i>
                    </a>
                      <a href="https://twitter.com" target="_blank" class="btn-group twitter">
                        <i class="fa fa-twitter"></i>
                    </a>
                      <a href="https://www.facebook.com/" target="_blank" class="btn-group facebook">
                        <i class="fa fa-facebook"></i>
                    </a>
					
                </div>
              </div>    
        </div>
      </div>
    </footer>

    
    <div class="copyright text center">
        <p> Copyright &copy; 2015, CS Chawra&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;
		 Designed by <a href="http://logicpalace.in/" target="_blank">Logic Palace Systems & Softwares</a></p>
    </div>

    
    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
	
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script>
      new WOW().init();
    </script>

  </body>


</html>
