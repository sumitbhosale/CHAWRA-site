    <!-- Main Container -->

    <div id="banners"></div>
    <div class="container">
	<?php
									$one="Select * From tblimportanttop  LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
		<div class="row container-kamn wow zoomIn">
			<img src="admin/img1/important/<?php echo $three['importanttop_img']; ?>" class="blog-post"  alt="Feature-img" align="right" height="300px" width="100%"> 
		</div>	
		   <?PHP  } ?>
<div class="panel panel-default">
<?php
									$one="Select * From tblimportantmidd  LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
				<div class="panel-heading" style="background:#99AABF;font-size:21px;color:#2D476F"><?php echo $three['importantmidd_title']; ?></div>
				 <?PHP  } ?>
					<div class="panel-body" style="background-color:#F1F1F1">		
		
		
		<?php
									$one="Select * From tblimportantmidd";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
        <div class="row">
           
                <div class="blockquote-info animated  clearfix">
                    <div class="col-md-6 wow fadeInLeft" style="text-decoration:underline;">
                       <a href="<?php echo $three['importantmidd_link']; ?>" target="_blank"><?php echo $three['importantmidd_text']; ?></a></br></br>
                    </div>
<?php	$three=mysql_fetch_array($two) ?>
					<div class="col-md-6 wow fadeInRight" style="text-decoration:underline;">
					   <a href="<?php echo $three['importantmidd_link']; ?>" target="_blank"><?php echo $three['importantmidd_text']; ?></a></br></br>
                    </div>
				
                </div>
            
  
        </div>
		<?PHP  } ?>
	</div>
</div>
		
	
    </div>
    <!--End Main Container -->