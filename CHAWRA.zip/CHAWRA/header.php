<!doctype html>
<html lang="en">
    

<head>

       
        <meta charset="utf-8">
        <title>CS CHAWARA</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
		
     
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
        <link href="http://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" type="text/css" media="all" href="assets/css/style-projects.html">
        

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.html">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.html">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.html">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.html">
		
		
		
		
    </head>
	
  <body>
<style type="text/css">

@media all and (max-width: 1000px) {
    #aa {
        display:none;
    }
}
</style>

    <!-- Header -->
         <?PHP   $page=$_GET["page"];  ?>  
    <nav id="navbar-section" class="navbar navbar-default navbar-static-top navbar-sticky " role="navigation">
        <div class="container">
        
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand wow fadeInDownBig" id="aa"  href="index.php"><img src="admin/img1/logo/CS-LOGO.png" style="float:left;box-shadow: 0px 0px 85px white;background-color:transperant;" width="180px" alt="Office"></a>   
                   
            </div>
			 <div class="navbar-header">
			 <div style="font-size:24px;color:#fff;padding-top:12px; width:100%">CHIRAG CHAWRA & CO <br><small  style="font-size:13px;color:#fff">Practicing Company Secretaries</small></div>
			 </div>
            <div id="navbar-spy" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav pull-right" >
                    <li <?PHP if($page=='') { ?> class="active" <?PHP } ?>>
                        <a href="index.php" style="color:#FFF;">Home</a>
                    </li>
                    <li <?PHP if($page=='about') { ?> class="active" <?PHP } ?>>
                        <a href="index.php?page=about" style="color:#FFF;">About</a>
                    </li>
					 <li <?PHP if($page=='services') { ?> class="active" <?PHP } ?>>
                        <a href="index.php?page=services" style="color:#FFF;">Services</a>
                    </li>
                    <li <?PHP if($page=='blog') { ?> class="active" <?PHP } ?>>
					    <a href="index.php?page=blog"  style="color:#FFF;">Blog</a>
                    </li>
                   
				    <li  <?PHP if($page=='important') { ?> class="active" <?PHP } ?>>
                        <a href="index.php?page=important"  style="color:#FFF;"><span>Important Links</span></a>
                    </li>
					<li  <?PHP if($page=='faqs') { ?> class="active" <?PHP } ?>>
                        <a href="index.php?page=faqs"  style="color:#FFF;"><span>Faqs</span></a>
                    </li>
				    <li  <?PHP if($page=='contact') { ?> class="active" <?PHP } ?>>
                        <a href="index.php?page=contact"  style="color:#FFF;"><span>Contact</span></a>
                    </li>
                </ul>         
            </div>
        </div>
    </nav>

    <!-- End Header -->
 