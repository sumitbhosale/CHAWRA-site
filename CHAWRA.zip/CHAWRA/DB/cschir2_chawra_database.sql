-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2016 at 02:30 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cschir2_chawra_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaboutlast`
--

CREATE TABLE IF NOT EXISTS `tblaboutlast` (
  `aboutlast_id` int(11) NOT NULL AUTO_INCREMENT,
  `aboutlast_pantitle` varchar(20) NOT NULL,
  `aboutlast_img` varchar(200) NOT NULL,
  `aboutlast_empname` varchar(30) NOT NULL,
  `aboutlast_emppos` varchar(40) NOT NULL,
  `aboutlast_propcont` varchar(2000) NOT NULL,
  PRIMARY KEY (`aboutlast_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblaboutlast`
--

INSERT INTO `tblaboutlast` (`aboutlast_id`, `aboutlast_pantitle`, `aboutlast_img`, `aboutlast_empname`, `aboutlast_emppos`, `aboutlast_propcont`) VALUES
(1, 'About Our Team', 'Chirag Photo New.jpg', 'CHIRAG CHANDRAKANT CHAWRA', 'PCS (Practicing since 12 Years)', '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Qualification- CS, L.L.B, B.Com,&nbsp;<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Membership No. F5643,<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;Practice No.7923.'),
(2, 'About Proprietor', 'sonal-pic.jpg', 'SONAL DESAI', 'CS', '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Membership No. A38968.&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;Qualification- CS,&nbsp;<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;LLB,<br>'),
(3, 'About Proprietor', 'vipin-pic.jpg', 'VIPIN ZANWAR', 'QUALIFIED CS', '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Qualification- CS,<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; PGDBM,&nbsp;B Com.'),
(4, 'About Proprietor', 'Photo_Sarita.jpg', ' SARITA PANDEY', 'CS TRAINEE', '&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Registration No.2213538,&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;Qualification- CS,&nbsp;<br>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;B.Com.');

-- --------------------------------------------------------

--
-- Table structure for table `tblaboutmidd`
--

CREATE TABLE IF NOT EXISTS `tblaboutmidd` (
  `aboutmidd_id` int(11) NOT NULL AUTO_INCREMENT,
  `aboutmidd_img` varchar(222) NOT NULL,
  `aboutmidd_title` varchar(50) NOT NULL,
  `aboutmidd_content` varchar(3000) NOT NULL,
  PRIMARY KEY (`aboutmidd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tblaboutmidd`
--

INSERT INTO `tblaboutmidd` (`aboutmidd_id`, `aboutmidd_img`, `aboutmidd_title`, `aboutmidd_content`) VALUES
(7, 'firm-profile.jpg', 'Our Firms History', '<span><b>Registered Company Name </b>:\r\nChirag Chawra &amp; Co.&nbsp;<span><br>\r\n<br>\r\n<b>Date of\r\nRegistration or Incorporation</b> : July 2002&nbsp;<br>\r\n<b>Country\r\nof Registration</b> : India&nbsp;<br>\r\n<br><b>Office Address</b> :<br>\r\nOffice No 5, First Floor,<br>\r\nMahalaxmi\r\nHeights,<br>\r\nNear\r\nHotel Keys, Pimpri,<br>\r\nPune -\r\n411018.<br>\r\n<br>\r\n<b>Tel</b> :\r\n020-64100174<br>\r\n<br>\r\n<b>Official\r\nInternet Site</b> : <a href="http://www.cschirag.com" target="" rel="">www.cschirag.com</a><br>\r\n<br>\r\n<b>E-mail </b>:\r\nchiragchawra@gmail.com&nbsp;</span></span>');

-- --------------------------------------------------------

--
-- Table structure for table `tblblogmidd`
--

CREATE TABLE IF NOT EXISTS `tblblogmidd` (
  `blogmidd_id` int(11) NOT NULL AUTO_INCREMENT,
  `blogmidd_pantitle` varchar(30) NOT NULL,
  `blogmidd_blogtitle` varchar(30) NOT NULL,
  `blogmidd_blogimg` varchar(222) NOT NULL,
  `blogmidd_blogcont` varchar(2000) NOT NULL,
  `blogmidd_blogdate` varchar(30) NOT NULL,
  PRIMARY KEY (`blogmidd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblblogmidd`
--

INSERT INTO `tblblogmidd` (`blogmidd_id`, `blogmidd_pantitle`, `blogmidd_blogtitle`, `blogmidd_blogimg`, `blogmidd_blogcont`, `blogmidd_blogdate`) VALUES
(3, 'Blogs', 'Alice in Wonderland, part dos', 'imag.jpg', 'You ought to be ashamed of yourself for asking such a simple question, added the Gryphon; and then they both sat silent and looked at poor Alice, who felt ready to sink into the earth. At last the Gryphon said to the Mock Turtle, Drive on, old fellow! Dont be all day about it! and he went on in these words: Yes, we went to school in the sea, though you maynt believe it—I never said I didnt! interrupted Alice. You did, said the Mock Turtle.', ''),
(4, 'Blogs', 'Alice in Wonderland, part dos', 'images.jpg', 'You ought to be ashamed of yourself for asking such a simple question, added the Gryphon; and then they both sat silent and looked at poor Alice, who felt ready to sink into the earth. At last the Gryphon said to the Mock Turtle, Drive on, old fellow! Dont be all day about it! and he went on in these words: Yes, we went to school in the sea, though you maynt believe it&#65533;I never said I didnt! interrupted Alice. You did, said the Mock Turtle.', '2015-09-26');

-- --------------------------------------------------------

--
-- Table structure for table `tblblogtop`
--

CREATE TABLE IF NOT EXISTS `tblblogtop` (
  `blogtop_id` int(11) NOT NULL AUTO_INCREMENT,
  `blogtop_img` varchar(222) NOT NULL,
  PRIMARY KEY (`blogtop_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblblogtop`
--

INSERT INTO `tblblogtop` (`blogtop_id`, `blogtop_img`) VALUES
(1, 'blog-writing-advice.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactmidd`
--

CREATE TABLE IF NOT EXISTS `tblcontactmidd` (
  `contactmidd_id` int(11) NOT NULL AUTO_INCREMENT,
  `contactmidd_img` varchar(222) NOT NULL,
  `contactmidd_title` varchar(50) NOT NULL,
  `contactmidd_cont` varchar(2000) NOT NULL,
  PRIMARY KEY (`contactmidd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblcontactmidd`
--

INSERT INTO `tblcontactmidd` (`contactmidd_id`, `contactmidd_img`, `contactmidd_title`, `contactmidd_cont`) VALUES
(1, 'contact_us.jpg', 'Contact Us', '<span><b><span>Find us\r\nat:<br>\r\n<br>\r\n</span></b><b>Head Office:-</b><span><br>\r\n</span>Office No 5, First Floor, Mahalaxmi\r\nHeights, Near Hotel Keys, Pimpri, Pune -411018&nbsp;<span><br>\r\n<b><span><br>\r\nBranch Office:-</span></b><span><br>\r\nFlat No A 302, Sai Marigold, Near Healing Touch Hospital, Pimple Saudagar,\r\nPune- 411027<br>\r\n<b><br>\r\n</b></span></span><b>Cell:</b>9923794174 / 7057109774<br>\r\n<b>Land Line</b>:020-64100174&nbsp;<br>\r\n<b><br>Email</b>:chiragchawra@gmail.com&nbsp;<span><br>\r\n<i></i></span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; chiragchawra@yahoo.com</span>');

-- --------------------------------------------------------

--
-- Table structure for table `tblfaqshole`
--

CREATE TABLE IF NOT EXISTS `tblfaqshole` (
  `faqshole_id` int(11) NOT NULL AUTO_INCREMENT,
  `faqshole_img` varchar(222) NOT NULL,
  `faqshole_title` varchar(40) NOT NULL,
  `faqshole_cont` longtext NOT NULL,
  PRIMARY KEY (`faqshole_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tblfaqshole`
--

INSERT INTO `tblfaqshole` (`faqshole_id`, `faqshole_img`, `faqshole_title`, `faqshole_cont`) VALUES
(6, 'FAQ_pic.jpg', 'Faqs', '1. What is the type of Business Entities Available in India?&nbsp;<br>The following types of Business entitles are available in India:<br><span>&#65533;&nbsp;Private Limited Company &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp;&nbsp;&#65533;&nbsp;Public Limited Company &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp;&nbsp;&#65533;&nbsp;Unlimited Company<br></span><span>&#65533;&nbsp;One Person Company &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp; &nbsp; &nbsp;&nbsp;&#65533;&nbsp;Sole Proprietorship<br></span>In addition to the above legal entities, the following types of\r\nentities are available for foreign investors/foreign companies doing business\r\nin India:<br><span>&#65533;&nbsp;Liaison Office &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&#65533;&nbsp;Representative Office\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&#65533;&nbsp;Project Office<br></span><span>&#65533;&nbsp;Branch Office &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&#65533;&nbsp;Wholly owned\r\nSubsidiary Company &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&#65533;&nbsp;Joint Venture\r\nCompany<br></span>__________________________________________________________________________________________________________________________________________________________<br>&nbsp;<span>2. What is a Private Limited Company?&nbsp;<span><br>\r\n</span>A Private Limited Company is a Company limited by shares in\r\nwhich there can be maximum 200 shareholders, no invitation can be made to the\r\npublic for subscription of shares or debentures, cannot make or accept deposits\r\nfrom Public and there are restriction on the transfer of shares. The liability\r\nof each shareholder is limited to the extent of the unpaid amount of the shares\r\nface value and the premium thereon in respect of the shares held by him.\r\nHowever, the liability of a Director / Manager of such a Company can at times\r\nbe unlimited. The minimum number of shareholders is 2.<i><br></i></span><span>A Private Limited Company is a Company limited by shares in\r\nwhich there can be maximum 200 shareholders, no invitation can be made to the\r\npublic for subscription of shares or debentures, cannot make or accept deposits\r\nfrom Public and there are restriction on the transfer of shares. The liability\r\nof each shareholder is limited to the extent of the unpaid amount of the shares\r\nface value and the premium thereon in respect of the shares held by him.\r\nHowever, the liability of a Director / Manager of such a Company can at times\r\nbe unlimited. The minimum number of shareholders is 2.<br></span>__________________________________________________________________________________________________________________________________________________________<i><br></i>3. What is a Public Limited Company?&nbsp;<br>A Public Limited Company is a Company limited by shares in which\r\nthere is no restriction on the maximum number of shareholders, transfer of\r\nshares and acceptance of public deposits. The liability of each shareholder is\r\nlimited to the extent of the unpaid amount of the shares face value and the\r\npremium thereon in respect of the shares held by him. However, the liability of\r\na Director / Manager of such a Company can at times be unlimited. The minimum\r\nnumber of shareholders is 7.<br>__________________________________________________________________________________________________________________________________________________________<i><br></i>4. What entity is best suited?&nbsp;<br>The choice of entity depends on circumstance of each case.\r\nPrivate Limited Company has lesser number of compliances requirements.\r\nTherefore, generally where there is no requirement of raising of finances\r\nthrough a public issue and the ownership is intended to be closely held by\r\nlimited number of persons, Private Limited Company is the best choice.<br>__________________________________________________________________________________________________________________________________________________________<i><br></i>5. What is the minimum paid-up capital of a Private Limited\r\nCompany?&nbsp;<br>The minimum paid up capital at the time of incorporation of a\r\nprivate limited company has to be Indian Rupees 1,00,000 .There is no upper\r\nlimit on having the authorized capital and the paid up capital. It can be\r\nincreased any time, by payment of additional stamp duty and registration fee.<br>__________________________________________________________________________________________________________________________________________________________<i><br></i>&nbsp;<span>6. What is the difference between authorized capital and paid up\r\ncapital?&nbsp;<span><br>\r\n</span>The authorized capital is the capital limit authorized by the\r\nRegistrar of Companies up to which the shares can be issued to the members /\r\npublic, as the case may be. The paid up share capital is the paid portion of\r\nthe capital subscribed by the shareholders.<br></span><span>The authorized capital is the capital limit authorized by the\r\nRegistrar of Companies up to which the shares can be issued to the members /\r\npublic, as the case may be. The paid up share capital is the paid portion of\r\nthe capital subscribed by the shareholders.<br></span>The authorized capital is the capital limit authorized by the\r\nRegistrar of Companies up to which the shares can be issued to the members /\r\npublic, as the case may be. The paid up share capital is the paid portion of\r\nthe capital subscribed by the shareholders.<br>__________________________________________________________________________________________________________________________________________________________<i><br></i>&nbsp;<span>7. When can the newly formed company start its business\r\noperations?&nbsp;<span><br>\r\n</span>On receipt of the certificate of incorporation, the public\r\ncompany has to complete certain other legal formalities such as a statutory\r\nmeeting (within 6 months), statutory report, etc. On completion of the said\r\nformalities and on filing of the statutory report with the ROC the ROC issues\r\nthe certification of commencement of business to the company. Thereafter, the\r\nPublic Company can start the business operations. The Private Company can start\r\nits business immediately on incorporation.<br></span><span>On receipt of the certificate of incorporation, the public\r\ncompany has to complete certain other legal formalities such as a statutory\r\nmeeting (within 6 months), statutory report, etc. On completion of the said\r\nformalities and on filing of the statutory report with the ROC the ROC issues\r\nthe certification of commencement of business to the company. Thereafter, the\r\nPublic Company can start the business operations. The Private Company can start\r\nits business immediately on incorporation.<br></span>On receipt of the certificate of incorporation, the public\r\ncompany has to complete certain other legal formalities such as a statutory\r\nmeeting (within 6 months), statutory report, etc. On completion of the said\r\nformalities and on filing of the statutory report with the ROC the ROC issues\r\nthe certification of commencement of business to the company. Thereafter, the\r\nPublic Company can start the business operations. The Private Company can start\r\nits business immediately on incorporation.<br>__________________________________________________________________________________________________________________________________________________________<i><br></i>&nbsp;<span>8. What other approvals are required for foreign investor in\r\nIndia?&nbsp;<span><br>\r\n</span>Generally, prior approval is required from the RBI before\r\ninvesting in India. Some categories of businesses are covered under automatic\r\napproval process. However, one has to apply for the same. There are some\r\npost-incorporation filing formalities after the remittance of capital from\r\noverseas to India and on issue of shares.<br></span><span>Generally, prior approval is required from the RBI before\r\ninvesting in India. Some categories of businesses are covered under automatic\r\napproval process. However, one has to apply for the same. There are some\r\npost-incorporation filing formalities after the remittance of capital from\r\noverseas to India and on issue of shares.<br></span>Generally, prior approval is required from the RBI before\r\ninvesting in India. Some categories of businesses are covered under automatic\r\napproval process. However, one has to apply for the same. There are some\r\npost-incorporation filing formalities after the remittance of capital from\r\noverseas to India and on issue of shares.<br>__________________________________________________________________________________________________________________________________________________________<i><br></i>&nbsp;<span>9. What are other formalities before or after incorporation?&nbsp;<span><br>\r\n</span>&#65533;&nbsp;Obtaining Permanent Account Number (PAN) from Income Tax\r\nDepartment<span><br>\r\n</span>&#65533;&nbsp;Obeying Shop and Establishments Act<span><br>\r\n</span>&#65533;&nbsp;Registration for Import Export code from Director&nbsp;General\r\nof Foreign Trade<span><br>\r\n</span>&#65533;&nbsp;Software Technologies Parks of India registration (STPI)\r\nif required<span><br>\r\n</span>&#65533;&nbsp;RBI approval for foreign companies investing in India and\r\nFIPB approval, if required.<span><br>\r\n</span>&#65533;&nbsp;The directors of an Indian company, both Indian and\r\nforeigner directors, are required to obtain Din and DSc<br></span><span>&#65533;&nbsp;Obtaining Permanent Account Number (PAN) from Income Tax\r\nDepartment<br></span><span>&#65533;&nbsp;Obeying Shop and Establishments Act<br></span><span>&#65533;&nbsp;Registration for Import Export code from Director&nbsp;General\r\nof Foreign Trade<br></span><span>&#65533;&nbsp;Software Technologies Parks of India registration (STPI)\r\nif required<br></span><span>&#65533;&nbsp;RBI approval for foreign companies investing in India and\r\nFIPB approval, if required.<br></span><span>&#65533;&nbsp;The directors of an Indian company, both Indian and\r\nforeigner directors, are required to obtain Din and DSc<br></span><span>&#65533;&nbsp;Obtaining Permanent Account Number (PAN) from Income Tax\r\nDepartment<br></span><span>&#65533;&nbsp;Obeying Shop and Establishments Act<br></span><span>&#65533;&nbsp;Registration for Import Export code from Director&nbsp;General\r\nof Foreign Trade<br></span><span>&#65533;&nbsp;Software Technologies Parks of India registration (STPI)\r\nif required<br></span><span>&#65533;&nbsp;RBI approval for foreign companies investing in India and\r\nFIPB approval, if required.<br></span><span>&#65533;&nbsp;The directors of an Indian company, both Indian and\r\nforeigner directors, are required to obtain Din and DSc<br>__________________________________________________________________________________________________________________________________________________________<br><br></span>&nbsp;<span>10. What is Director Identification Number (DIN)?&nbsp;<span><br>\r\n</span>It is an unique Identification Number allotted to an individual\r\nwho is an existing director of a company or intends to be appointed as director\r\nof a company pursuant to section 266A &amp; 266B of the Companies Act, 1956 (as\r\namended vide Act No 23 of 2006).<br></span><span>It is an unique Identification Number allotted to an individual\r\nwho is an existing director of a company or intends to be appointed as director\r\nof a company pursuant to section 266A &amp; 266B of the Companies Act, 1956 (as\r\namended vide Act No 23 of 2006).<br></span>It is an unique Identification Number allotted to an individual\r\nwho is an existing director of a company or intends to be appointed as director\r\nof a company pursuant to section 266A &amp; 266B of the Companies Act, 1956 (as\r\namended vide Act No 23 of 2006).<br>11. Who can file an application for allotment of DIN?&nbsp;<br>Any individual, who is an existing director of a company or\r\nintends to be appointed as a director of the company, can file an application\r\nfor allotment of DIN.<br>__________________________________________________________________________________________________________________________________________________________<i><br></i>&nbsp;<span>12. Who will allot the DIN ?&nbsp;<span><br>\r\n</span>Central Government (Office of Regional Director (Northern\r\nRegion), Ministry of Corporate Affairs, NOIDA) will allot the DIN.<br></span><span>Central Government (Office of Regional Director (Northern\r\nRegion), Ministry of Corporate Affairs, NOIDA) will allot the DIN.<br></span>Central Government (Office of Regional Director (Northern\r\nRegion), Ministry of Corporate Affairs, NOIDA) will allot the DIN.<br>__________________________________________________________________________________________________________________________________________________________&nbsp;<i><br></i><br>13. What is a Digital Signature Certificate?&nbsp;<br>Digital Signature Certificates (DSC) are the digital equivalent\r\n(that is electronic format) of physical or paper certificates. Examples of\r\nphysical certificates are drivers licenses, passports or membership cards. Certificates\r\nserve as proof of identity of an individual for a certain purpose; for example,\r\na drivers license identifies someone who can legally drive in a particular\r\ncountry. Likewise, a digital certificate can be presented electronically to\r\nprove your identity, to access information or services on the Internet or to\r\nsign certain documents digitally.\r\n\r\n&nbsp;<br>__________________________________________________________________________________________________________________________________________________________<i><br></i><br>14. Why is Digital Signature Certificate (DSC) required?&nbsp;<br>Like physical documents are signed manually, electronic\r\ndocuments, for example e-forms are required to be signed digitally using a\r\nDigital Signature Certificate.\r\n\r\n&nbsp;<br>__________________________________________________________________________________________________________________________________________________________<br><br>15. Who issues the Digital Signature Certificate?&nbsp;<br>A licensed Certifying Authority (CA) issues the digital\r\nsignature. Certifying Authority (CA) means a person who has been granted a\r\nlicense to issue a digital signature certificate under Section 24 of the Indian\r\nIT-Act 2000.&nbsp;<br><span>The list of licensed CAs along with their contact information is\r\navailable on the MCA portal (<a href="http://www.mca.gov.in/" target="" rel="">www.mca.gov.in</a>).<br></span>__________________________________________________________________________________________________________________________________________________________<i><br></i><br>&nbsp;<span>16. What are the\r\ndifferent types of Digital Signature Certificates valid for MCA21 program?&nbsp;<span><br>\r\n</span>The different types of Digital Signature Certificates are: Class\r\n2: Here, the identity of a person is verified against a trusted, pre-verified\r\ndatabase.&nbsp;<span><br>\r\n</span>Class 3: This is the highest level where the person needs to\r\npresent himself or herself in front of a Registration Authority (RA) and prove\r\nhis/ her identity.&nbsp;&nbsp;<br></span><span>The different types of Digital Signature Certificates are: Class\r\n2: Here, the identity of a person is verified against a trusted, pre-verified\r\ndatabase.&nbsp;<br></span><span>Class 3: This is the highest level where the person needs to\r\npresent himself or herself in front of a Registration Authority (RA) and prove\r\nhis/ her identity.&nbsp;&nbsp;<br></span>The different types of Digital Signature Certificates are: Class\r\n2: Here, the identity of a person is verified against a trusted, pre-verified\r\ndatabase.&nbsp;<br>Class 3: This is the highest level where the person needs to\r\npresent himself or herself in front of a Registration Authority (RA) and prove\r\nhis/ her identity.&nbsp;&nbsp;\r\n\r\n&nbsp;<br><br>');

-- --------------------------------------------------------

--
-- Table structure for table `tblhomemidd`
--

CREATE TABLE IF NOT EXISTS `tblhomemidd` (
  `homemidd_id` int(22) NOT NULL AUTO_INCREMENT,
  `homemidd_title` varchar(50) NOT NULL,
  `homemidd_content` varchar(2222) NOT NULL,
  PRIMARY KEY (`homemidd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tblhomemidd`
--

INSERT INTO `tblhomemidd` (`homemidd_id`, `homemidd_title`, `homemidd_content`) VALUES
(5, 'Welcome To Our Website', 'We intend to provide our\r\nclients with a smart, Secure and best Services in Corporate and legal Sector.\r\nWe intend to provide our clients with a smart, Secure and best Services in\r\nCorporate and legal Sector We intend to provide our clients with a smart,\r\nSecure and best Services in Corporate and legal Sector, We intend to provide\r\nour clients with a smart, Secure and best Services in Corporate and legal\r\nSector.');

-- --------------------------------------------------------

--
-- Table structure for table `tblhomemiddimages`
--

CREATE TABLE IF NOT EXISTS `tblhomemiddimages` (
  `homemiddimages_id` int(11) NOT NULL AUTO_INCREMENT,
  `homemiddimages_img` varchar(222) NOT NULL,
  `homemiddimages_title` varchar(30) NOT NULL,
  `homemiddimages_content` varchar(2000) NOT NULL,
  `homemiddimages_homemidd_id` int(11) NOT NULL,
  PRIMARY KEY (`homemiddimages_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tblhomemiddimages`
--

INSERT INTO `tblhomemiddimages` (`homemiddimages_id`, `homemiddimages_img`, `homemiddimages_title`, `homemiddimages_content`, `homemiddimages_homemidd_id`) VALUES
(11, '568baae878dccimg3.png', 'Our Vision', 'We intend to provide our\r\nclients with a smart, Secure and best Services in Corporate and legal Sector.', 5),
(12, '568bab0c1df64img1.png', 'Our Mission', 'Profitable growth through the\r\nSuperior Secretarial services, quality of Work &amp; Commitments to our clients\r\nand Associates.', 5),
(13, '568bab2289238img2.png', 'Our Goal', 'We strive to be a most\r\nsuccessful and progressive Company Secretary Firm with efficient and\r\ncost-effective service and supporting them in all the areas for our Clients.', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblimportantmidd`
--

CREATE TABLE IF NOT EXISTS `tblimportantmidd` (
  `importantmidd_id` int(11) NOT NULL AUTO_INCREMENT,
  `importantmidd_title` varchar(50) NOT NULL,
  `importantmidd_link` varchar(50) NOT NULL,
  `importantmidd_text` varchar(50) NOT NULL,
  PRIMARY KEY (`importantmidd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tblimportantmidd`
--

INSERT INTO `tblimportantmidd` (`importantmidd_id`, `importantmidd_title`, `importantmidd_link`, `importantmidd_text`) VALUES
(1, 'Important Links', 'http://www.mca.gov.in/', '1.Ministry of corporate affairs'),
(2, 'Important Links', 'http://www.icsi.edu/', '2.Institute of company secretaries of India'),
(3, 'Important Links', 'http://www.icai.org.in/', '3.Institute of chartered accountants of India'),
(4, 'Important Links', 'http://icmai.in/', '4.Institute of works and cost accountants of India'),
(5, 'Important Links', 'https://www.rbi.org.in/', '5.Reserve Bank of India'),
(6, 'Important Links', 'http://www.sebi.gov.in/sebiweb/', '6.Securities and Exchange board of India'),
(7, 'Important Links', 'https://incometaxindiaefiling.gov.in/', '7.Income tax'),
(8, 'Important Links', 'http://www.dgft.org', '8.Director General of foreign Trade'),
(9, 'Important Links', 'http://www.cbec.gov.in/', '9.Central Board of Excise and Customs'),
(10, 'Important Links', 'https://www.aces.gov.in/', '10.Service Tax'),
(11, 'Important Links', 'http://fipb.gov.in/', '11.Foreign Exchange Promotion Board '),
(12, 'Important Links', 'http://www.nseindia.com/', '12.NSE'),
(13, 'Important Links', 'http://www.bseindia.com/', '13.BSE');

-- --------------------------------------------------------

--
-- Table structure for table `tblimportanttop`
--

CREATE TABLE IF NOT EXISTS `tblimportanttop` (
  `importanttop_id` int(11) NOT NULL AUTO_INCREMENT,
  `importanttop_img` varchar(222) NOT NULL,
  PRIMARY KEY (`importanttop_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblimportanttop`
--

INSERT INTO `tblimportanttop` (`importanttop_id`, `importanttop_img`) VALUES
(1, 'Important-links.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblservicemidd`
--

CREATE TABLE IF NOT EXISTS `tblservicemidd` (
  `servicemidd_serviceimg` varchar(222) NOT NULL,
  `servicemidd_servicecont` varchar(2000) NOT NULL,
  `servicemidd_id` int(11) NOT NULL AUTO_INCREMENT,
  `servicemidd_pantitle` varchar(40) NOT NULL,
  `servicemidd_servicetitle` varchar(40) NOT NULL,
  PRIMARY KEY (`servicemidd_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tblservicemidd`
--

INSERT INTO `tblservicemidd` (`servicemidd_serviceimg`, `servicemidd_servicecont`, `servicemidd_id`, `servicemidd_pantitle`, `servicemidd_servicetitle`) VALUES
('CompaniesActnew.jpg', '<span><b>The\r\nCompanies Act 2013<br></b><b><u></u></b></span>\r\n\r\n<span>Company Formation<span><br>\r\nCompany\r\nRoutine Matters<br>\r\nConversion\r\nof Companies<br>\r\nClosure\r\nof Companies</span></span>', 1, 'Our Services', 'The Companies Act 2013'),
('llp.jpg', '<span><b>The Limited Liability\r\nPartnership Act, 2008</b><span><br>\r\nLLP\r\nFormation<br>\r\nLLP\r\nRoutine Matters<br>\r\nConversion\r\nof LLP<br>\r\nClosure\r\nof LLP</span></span>', 2, 'Our Services', 'The Limited Liability Partnership Act, 2'),
('CentralExcise.jpg', '<span><b>Central\r\nExcise Act 1944</b><span><br>\r\nExcise Registration<br>\r\nExcise Return<br>\r\nExcise Audit and Valuation<br>\r\nAppeal<br>\r\nOpinions</span></span>', 3, 'Our Services', 'Central Excise Act 1944'),
('unnamed.png', '<span><b>Service\r\nTax Registration</b><span><br>\r\nService\r\nTax Returns<br>\r\nService\r\nTax Audit and Valuation<br>\r\nAppeal<br>\r\nOpinions</span></span>', 4, 'Our Services', 'Service Tax Registration'),
('FEMA.jpg', '<span><b>Foreign\r\nExchange Management Act 1999</b><span><br>\r\nOpening\r\nof Branch Office in India<br>\r\nForeign\r\nDirect Investment<br>\r\nRBI\r\nCompliances<br>\r\nExternal\r\nCommercial Borrowings<br>\r\nFiling of\r\nReturns &amp; Statements<br>\r\nImport\r\nExport Policies &amp; Procedures</span></span>', 5, 'Our Services', 'Foreign Exchange Management Act 1999'),
('other.jpg', '<span><b>Other Services</b><span><br>\r\nIEC code\r\nregistration<br>\r\nRegistration\r\nof Shops and Establishments<br>\r\nRegistration\r\nof Trademarks, Patents, Copyrights<br>\r\nMSME\r\nRegistration<br>All Types of Digital Signatures</span></span>', 6, 'Our Services', 'Other Services');

-- --------------------------------------------------------

--
-- Table structure for table `tblserviceside`
--

CREATE TABLE IF NOT EXISTS `tblserviceside` (
  `serviceside_id` int(11) NOT NULL AUTO_INCREMENT,
  `serviceside_img` varchar(222) NOT NULL,
  `serviceside_link` varchar(70) NOT NULL,
  PRIMARY KEY (`serviceside_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tblserviceside`
--

INSERT INTO `tblserviceside` (`serviceside_id`, `serviceside_img`, `serviceside_link`) VALUES
(6, 'images-blog.jpg', 'http://logicpalace.in/'),
(7, 'images-blog.jpg', 'http://logicpalace.in/'),
(8, 'images-blog.jpg', 'http://logicpalace.in/'),
(9, 'images-blog.jpg', 'http://logicpalace.in/');

-- --------------------------------------------------------

--
-- Table structure for table `tblservicetop`
--

CREATE TABLE IF NOT EXISTS `tblservicetop` (
  `servicetop_id` int(11) NOT NULL AUTO_INCREMENT,
  `servicetop_img` varchar(222) NOT NULL,
  PRIMARY KEY (`servicetop_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblservicetop`
--

INSERT INTO `tblservicetop` (`servicetop_id`, `servicetop_img`) VALUES
(4, 'servicesbanner.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblslider`
--

CREATE TABLE IF NOT EXISTS `tblslider` (
  `slider_id` int(10) NOT NULL AUTO_INCREMENT,
  `slider_img` varchar(222) NOT NULL,
  `slider_accept` int(1) NOT NULL,
  PRIMARY KEY (`slider_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tblslider`
--

INSERT INTO `tblslider` (`slider_id`, `slider_img`, `slider_accept`) VALUES
(17, '1231.jpg', 1),
(18, 'Contact-Slashsquare.jpg', 1),
(20, 'CSRNEW.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE IF NOT EXISTS `tbluser` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) NOT NULL,
  `user_pass` varchar(200) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_full_name` varchar(222) NOT NULL,
  `user_type` varchar(222) NOT NULL,
  `user_s_type` varchar(100) NOT NULL,
  `user_access` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`user_id`, `user_name`, `user_pass`, `user_email`, `user_full_name`, `user_type`, `user_s_type`, `user_access`) VALUES
(4, '111', '111', 'Admin@gmail.com', 'CS CHAWRA', 'Super_Admin', 'Administrator', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
