    <!-- Main Container -->
    <div id="banners"></div>
        <div class="container">
		 <?php
									$one="Select * From tblblogtop LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
			<div class="row container-kamn wow zoomIn">
				<img src="admin/img1/blog/<?php echo $three['blogtop_img']; ?>" class="blog-post"  alt="Feature-img" align="right" height="300px" width="100%"> 
			</div>	
			<?PHP   } ?>
		<div class="panel panel-default">
		<?php
									$one="Select * From tblblogmidd LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
				<div class="panel-heading" style="background:#99AABF;font-size:21px;color:#2D476F"><?php echo $three['blogmidd_pantitle']; ?></div>
				<?php } ?>
					<div class="panel-body" style="background-color:#F1F1F1">
					
            <div class="row">
                <div class="col-md-12"> 
				<?php
									$one="Select * From tblblogmidd";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
                    <div class="blog-post">
                        <h1 class="blog-title wow zoomIn" data-wow-delay=".8s">
                            <i class="fa  fa-file-text"></i>
                          <?php echo $three['blogmidd_blogtitle']; ?>
                        </h1>
                        <br>
                        <img src="admin/img1/blog/<?php echo $three['blogmidd_blogimg']; ?>" alt="Feature-img" align="right" style="height:200px" width="100%" data-wow-delay="1.2s" class="blog-image img-aa wow fadeInDown">
                        <br>
                        <p class="wow fadeInLeft">
                           <?php echo $three['blogmidd_blogcont']; ?>
                        </p>
                        <span class="badge">Posted <?php echo $three['blogmidd_blogdate']; ?></span>
                    </div>
					
                    <hr>
				  <?php } ?>
				</div>
				
			</div>
		</div>
	</div>
</div>
        <!--End Main Container -->