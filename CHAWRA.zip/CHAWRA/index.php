
<?PHP 

include("admin/connect/connect.php"); 
?>
<?php error_reporting(E_ERROR | E_WARNING | E_PARSE); ?>



<?Php include("header.php"); ?>




<?PHP
	if($_REQUEST['page']!='')
    {
        include($_REQUEST['page'].".php");	
    }
    else
	{
        include_once "body.php";
		
    }
?>

		
<?Php include("footer.php"); ?>



















