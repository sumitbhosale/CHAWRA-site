    <!-- Main Container -->

    <div id="banners"></div>
	<?php
									$one="Select * From tblfaqshole  LIMIT 1";
                                    $two=mysql_query($one);
                                    while($three=mysql_fetch_array($two))
                                    {
										
										
						?>
    <div class="container">
		<div class="row container-kamn wow zoomIn">
			<img src="admin/img1/faqs/<?php echo $three['faqshole_img']; ?>" class="blog-post"  alt="Feature-img" align="right" height="300px" width="100%"> 
		</div>	
        <div class="row">
            <div class="col-md-12">
                <div class="blockquote-info  clearfix">
				   <div class="panel panel-default">
					  <div class="panel-heading" style="background:#99AABF;font-size:21px;color:#2D476F"><?php echo $three['faqshole_title']; ?></div>
						<div class="panel-body"  style="background-color:#F1F1F1">
						<p class="alert">
						
						<?php echo $three['faqshole_cont']; ?>
                   				
                   				</p>
						
						
						</div>
				   </div>
				
                   
                </div>
            </div>
  
        </div>
		
	
    </div>
	    <?PHP   } ?>
    <!--End Main Container -->